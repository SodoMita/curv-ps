export interface Example { id: string; name: string; blurb: string; src: string; group: "layout" | "curv" }

export const EXAMPLES: Example[] = [
  {
    group: "layout",
    id: "split",
    name: "Responsive split",
    blurb: "Cassowary-style layout: resize the canvas and psolve re-solves the constraints every frame.",
    src: `// Two panes sharing the parent width.  Nothing here is positioned by
// hand: every x/y/w/h comes out of the \`solve\` block, which psolve
// (convex QP, active-set) solves in microseconds on each resize.
let
  pad = 20;
  L = solve {
    var left, right : box;

    left.x == pad;                 left.y == pad;
    left.right + 16 == right.x;    right.y == left.y;
    right.right == parent.width - pad;
    left.bottom == parent.height - pad;
    right.h == left.h;

    left.w == 2 * right.w;         // the classic AutoLayout ratio
    weak: right.w == 260;          // preferred width, yields under pressure
  };
in union [
  card L.left,
  card L.right,
  text "left.w == 2 * right.w" 16 >> colour fg >> at L.left,
  text (strcat ["left ", round L.left.w, " px"]) 13 >> colour muted
    >> translate (L.left.cx, L.left.cy + 28),
  text (strcat ["right ", round L.right.w, " px"]) 13 >> colour muted
    >> translate (L.right.cx, L.right.cy + 28),
  text "right" 16 >> colour fg >> at L.right,
]`,
  },
  {
    group: "layout",
    id: "dashboard",
    name: "Dashboard",
    blurb: "Sidebar, header and an equal-width card grid — all from one constraint system, with soft preferences.",
    src: `// A whole dashboard from one solve block.  Try dragging the canvas
// width: the sidebar shrinks between its bounds before the cards do.
let
  pad = 16; gap = 14; n = 6; cols = 3;
  L = solve {
    var side, head, main : box;
    var cards : box[n];

    // frame
    side.pos == (pad, pad);         side.bottom == parent.height - pad;
    head.y == pad;                  head.h == 56;
    head.x == side.right + gap;     head.right == parent.width - pad;
    main.x == head.x;               main.right == head.right;
    main.y == head.bottom + gap;    main.bottom == side.bottom;

    // sidebar prefers 200px but may compress
    weak: side.w == 200;   side.w >= 96;   side.w <= 220;

    // 3-column grid of equal cards inside main
    for (i in 0..n-1) {
      c = i % cols;  r = floor (i / cols);
      cards.[i].w == cards.[0].w;   cards.[i].h == cards.[0].h;
      cards.[i].x == main.x + c * (cards.[0].w + gap);
      cards.[i].y == main.y + r * (cards.[0].h + gap);
    }
    cards.[cols-1].right == main.right;
    cards.[n-1].bottom == main.bottom;
  };
  titles = ["Revenue", "Sessions", "Latency", "Errors", "Signups", "Churn"];
  values = ["$48.2k", "128k", "42 ms", "0.3%", "1,204", "1.9%"];
  ratios = [0.72, 0.55, 0.31, 0.12, 0.64, 0.22];
  colours = [accent, accent_2, success, danger, accent_3, warning];
  nav i = box (L.side.x + 12, L.side.y + 64 + i*40, L.side.w - 24, 32);
in union [
  card L.side,
  avatar (box (L.side.x + 12, L.side.y + 12, 36, 36)) "CV",
  for (i in 0..4)
    union [ frame_r 8 (nav i) >> colour (if i == 0 then surface_3 else surface),
            circle 8 >> colour (if i == 0 then accent else border)
              >> translate ((nav i).x + 14, (nav i).cy) ],
  panel L.head,
  text_left "Overview" 18 >> colour fg >> translate (L.head.x + 18, L.head.cy + 6),
  button (box (L.head.right - 116, L.head.y + 11, 104, 34)) "New report",
  for (i in 0..n-1)
    let b = cards.[i]; in union [
      card b,
      text_left titles.[i] 12 >> colour muted >> translate (b.x + 16, b.y + 26),
      text_left values.[i] 22 >> colour fg >> translate (b.x + 16, b.y + 56),
      progress (box (b.x + 16, b.bottom - 24, b.w - 32, 6)) ratios.[i] colours.[i],
    ]
] where cards = L.cards`,
  },
  {
    group: "layout",
    id: "buttons",
    name: "Intrinsic sizing",
    blurb: "Buttons measure their labels (text_width) and the solver distributes the leftover space.",
    src: `// Content-driven layout: each button must be at least as wide as its
// label + padding, all buttons share one width if possible (weak), and
// the row is centred in the parent.  Change a label and watch it re-flow.
let
  labels = ["Cancel", "Save draft", "Publish now", "Schedule for later"];
  n = count labels;  gap = 10;  h = 42;
  L = solve {
    var b : box[n];
    var row : box;
    row.h == h;   row.cy == parent.height / 2;
    row.cx == parent.width / 2;                 // centred row
    row.w <= parent.width - 32;
    for (i in 0..n-1) {
      b.[i].h == h;   b.[i].y == row.y;
      b.[i].w >= text_width labels.[i] 14 + 36; // intrinsic minimum
      weak: b.[i].w == b.[0].w;                 // equal widths when room allows
    }
    b.[0].x == row.x;
    for (i in 1..n-1) b.[i].x == b.[i-1].right + gap;
    b.[n-1].right == row.right;
    maximize row.w;                             // stretch (bounded above)
  };
in union [
  frame_r 14 (inset (-14) L.row) >> colour surface,
  ghost_button L.b.[0] labels.[0],
  ghost_button L.b.[1] labels.[1],
  button L.b.[2] labels.[2],
  button L.b.[3] labels.[3],
  text "b[i].w >= text_width label 14 + 36" 12 >> colour muted
    >> translate (parent.cx, L.row.bottom + 44),
]`,
  },
  {
    group: "layout",
    id: "tooltip",
    name: "Constrained tooltip",
    blurb: "Move the mouse: the tooltip wants to follow the cursor (weak) but must stay inside the canvas (required).",
    src: `// Soft goals vs. hard limits.  The tooltip *wants* to sit centred above
// the cursor, but it *must* stay 10px inside the parent.  psolve finds
// the least-squares compromise (this is an honest convex QP).
let
  title = "tip.cx == mouse.x  (weak)";
  L = solve {
    var tip, arrow : box;
    tip.w == text_width title 12 + 32;  tip.h == 54;   // sized by its label
    arrow.size == (14, 14);
    weak: tip.cx == mouse.x;
    weak: tip.bottom == mouse.y - 18;
    tip.x >= 10;  tip.right <= parent.width - 10;
    tip.y >= 10;  tip.bottom <= parent.height - 10;
    arrow.cx == tip.cx;  arrow.cy == tip.bottom;
    medium: arrow.cx == mouse.x;
  };
  label = strcat ["(", round mouse.x, ", ", round mouse.y, ")"];
in union [
  frame parent >> gradient (surface, ink) ((0, 0), (0, parent.height)),
  for (x in 0..parent.width by 40) line ((x, 0), (x, parent.height)) 1 >> colour surface_2,
  for (y in 0..parent.height by 40) line ((0, y), (parent.width, y)) 1 >> colour surface_2,
  circle 10 >> colour accent_2 >> translate mouse.pos,
  ring 26 2 >> colour accent_2 >> opacity 0.5 >> translate mouse.pos,
  union [
    square 14 >> rotate (pi/4) >> colour surface_3 >> at L.arrow,
    frame_r 12 L.tip >> colour surface_3,
  ] >> shadow (0, 6) 14,
  text title 12 >> colour fg >> translate (L.tip.cx, L.tip.y + 20),
  text label 12 >> colour muted >> translate (L.tip.cx, L.tip.y + 38),
]`,
  },
  {
    group: "layout",
    id: "chart",
    name: "Animated chart",
    blurb: "Bars re-solved every frame: equal spacing, bounded widths, heights from data driven by time.",
    src: `// Live data + layout solver at 60 fps.  Bar spacing/width is decided
// by psolve (LP/QP), the bar heights are plain Curv math on \`time\`.
let
  n = 12;  pad = 28;  gap_min = 6;
  data = [for (i in 0..n-1) 0.5 + 0.45 * sin (time*1.3 + i*0.7) * cos (time*0.4 + i)];
  L = solve {
    var plot : box;   var bars : box[n];   var gap;
    plot.pos == (pad, pad);  plot.right == parent.width - pad;
    plot.bottom == parent.height - pad - 24;
    gap >= gap_min;
    for (i in 0..n-1) {
      bars.[i].w == bars.[0].w;   bars.[i].bottom == plot.bottom;
      bars.[i].h == plot.h * data.[i];
      bars.[i].w <= 64;
    }
    bars.[0].x == plot.x;
    for (i in 1..n-1) bars.[i].x == bars.[i-1].right + gap;
    bars.[n-1].right == plot.right;
    weak: gap == 14;                       // preferred gap; width absorbs the rest
  };
in union [
  frame_r 18 (inset (-12) L.plot) >> colour surface,
  for (k in 0..4) line ((L.plot.x, L.plot.y + k*L.plot.h/4), (L.plot.right, L.plot.y + k*L.plot.h/4)) 1 >> colour border,
  for (i in 0..n-1)
    frame_r 6 L.bars.[i] >> gradient (accent_2, accent) ((0, L.plot.y), (0, L.plot.bottom)),
  for (i in 0..n-1)
    text (round (data.[i] * 100)) 11 >> colour muted
      >> translate (L.bars.[i].cx, L.bars.[i].y - 10),
  text (strcat ["gap = ", round L.gap, "px   bar = ", round L.bars.[0].w, "px"]) 12
    >> colour muted >> translate (parent.cx, parent.height - 16),
]`,
  },
  {
    group: "layout",
    id: "frep",
    name: "Pure F-Rep",
    blurb: "Classic Curv: signed-distance CSG (smooth union, difference, offset) with the solver placing the parts.",
    src: `// Curv's soul: shapes are distance fields, combined with CSG.  The
// solver only decides *where* the three blobs live so they always fit.
let
  L = solve {
    var a, b, c : box;
    a.size == (160, 160);  b.size == (120, 120);  c.size == (90, 90);
    a.cy == parent.cy;  b.cy == a.cy - 40;  c.cy == a.cy + 50;
    b.x == a.cx + 20;   c.x == b.cx + 10;
    a.cx + (c.right - a.x) / 2 == parent.cx + 40;   // group centred
    a.x >= 20;  c.right <= parent.width - 20;
  };
  blob = smooth_union 30 [
    circle a.w >> translate a.center,
    circle b.w >> translate b.center,
    rrect c.size 20 >> rotate (time*0.7) >> translate c.center,
  ] where {a = L.a; b = L.b; c = L.c};
  hole = circle 70 >> translate (L.a.cx - 30, L.a.cy + 10);
  body = difference [blob, hole >> offset (10 * sin time)];
in union [
  body >> gradient (accent, accent_3) ((L.a.x, 0), (L.c.right, 0)),
  body >> stroke 2 >> colour white >> opacity 0.35,
  hole >> stroke 1 >> colour accent_2 >> opacity 0.6,
  text "difference [smooth_union 30 [..], circle 70]" 12 >> colour muted
    >> translate (parent.cx, parent.height - 22),
]`,
  },
  {
    group: "curv",
    id: "mandelbrot",
    name: "Mandelbrot",
    blurb: "curv/examples/mandelbrot.curv \u2014 a make_shape whose colour function runs a 100-iteration escape loop in the fragment shader (do/local/:=/for \u2026 until).",
    src: "make_shape {\n    dist = everything.dist;\n    colour [x,y,_,_] =\n        do\n            local z = [x,y];\n            local hsv = [0,0,0];\n            local done = false;\n            for (i in 0 ..< 100 until done) (\n                z := csqr z + [x,y];\n                if (dot[z,z] > 4) (\n                    local cr = (i-1)-log(log(dot[z,z])/log 2)/log 2;\n                    hsv := [0.95+.012*cr, 1, .2+.4*(1+sin(.3*cr))];\n                    done := true;\n                )\n            );\n        in sRGB.HSV hsv;\n    bbox = [[-2.5,-2,-2],[1.5,2,2]];\n    is_2d = true;\n}",
  },
  {
    group: "curv",
    id: "liquid_paint",
    name: "Liquid paint",
    blurb: "curv/examples/liquid_paint.curv \u2014 parametric sliders + animated plasma texture (uses t = time).",
    src: "// Liquid Paint 2D plasma.\n// try: Iter=2, Amp=3 and zoom out a bit\n// Inspired by: http://glslsandbox.com/e#8067.3\n\nparametric\n    Iter :: int_slider[0,50] = 50;\n    Amp :: slider[0,3] = 0.6;\n    Speed :: slider[0,4] = 1;\nin\nmake_shape {\n    colour [x,y,z,t] =\n        do\n            local p = [x,y];\n            local t = t*Speed;\n            for (i in 1..Iter)\n                p := p + Amp/i*sin(i*p.[[Y,X]] + t + [0,tau/2]) + 1;\n        in sRGB[0.5*sin(3.0*p.[X])+0.5, 0.5*sin(3.0*p.[Y])+0.5, sin(p.[X]+p.[Y])];\n    dist p = -inf;\n    bbox = [[-1,-1,0],[1,1,0]];\n    is_2d = true;\n}",
  },
  {
    group: "curv",
    id: "log_spiral",
    name: "Log spiral",
    blurb: "curv/examples/log_spiral.curv \u2014 user distance field with nested lets and an if/else in SubCurv.",
    src: "// Logarithmic spiral.\n// https://swiftcoder.wordpress.com/2010/06/21/logarithmic-spiral-distance-field/\n//\n// `s` is a scaling parameter. You could also use `scale(s)`.\n//\n// Growth rate parameter `g` controls how tightly and in which direction\n// the spiral spirals.\n// `g=0.1759` is a measured growth rate for a Nautilus shell.\n// This implementation requires 0 < g < 1 for a counterclockwise spiral,\n// or -1 < g < 0 for a clockwise spiral.\n//\n// The spiral makes a constant angle t with any radius vector.\n// You can define `g` as `cot t`.\n//\n// Distance field looks okay for g=.2, is bonkers for more extreme values.\n\nlet\n    log_spiral [s, g] = make_shape {\n        dist [x,y,_,_] =\n            let r = mag[x,y];\n                t = phase[x,y];\n            in if (r == 0)\n                0\n            else\n                let n = (log(r/s)/g - t) / tau;\n                    upper_r = s * e^(g*(t+tau*ceil n));\n                    lower_r = s * e^(g*(t+tau*floor n));\n                in (min[abs(upper_r-r), abs(r-lower_r)] - r*abs g)\n                    / 1.24; /* empirical Lipschitz factor for g=.2 */\n        is_2d = true;\n    };\n\nin\nlog_spiral [1, 0.2]",
  },
  {
    group: "curv",
    id: "plot",
    name: "Function plot",
    blurb: "curv/examples/plot.curv \u2014 plot f = make_shape { dist p = p.[Y] - f(p.[X]) } >> show_axes. Drag to pan, wheel to zoom.",
    src: "let\n    plot f = make_shape {\n        dist p = p.[Y] - f(p.[X]);\n        is_2d = true;\n    } >> show_axes;\n\nin\nplot (x->sin x * sin(x*10))",
  },
  {
    group: "curv",
    id: "polygon",
    name: "Polygons",
    blurb: "curv/examples/polygon.curv \u2014 regular_polygon, polygon, list comprehension, sRGB.hue, move/rotate/colour.",
    src: "let\n    n = 5;\nin\nunion [\n    for (i in 0..<n)\n        regular_polygon (i+3) >> move[0,3] >> rotate(tau/n*i)\n          >> colour (sRGB.hue(i/n)),\n    polygon ([for (a in 0..<tau by tau/5) cis(a+tau/4)*2].[[0,2,4,1,3]])\n        >> colour black\n]",
  },
  {
    group: "curv",
    id: "smoke",
    name: "Smoke",
    blurb: "curv/examples/smoke.curv \u2014 fbm noise (Book of Shaders) as a colour function; loops with := on let-bound variables.",
    src: "// Credit: Patricio Gonzalez 2015 https://thebookofshaders.com/13/\n\nlet\n    random xy = frac(sin(dot[xy, [12.9898,78.233]])*43758.5453123);\n\n    // Based on Morgan McGuire @morgan3d\n    // https://www.shadertoy.com/view/4dS3Wd\n    noise xy =\n        let i = floor xy;\n            f = xy - i;\n\n            // Four corners in 2D of a tile\n            a = random(i);\n            b = random(i + [1, 0]);\n            c = random(i + [0, 1]);\n            d = random(i + [1, 1]);\n\n            u = f * f * (3 - 2 * f);\n\n        in lerp[a, b, u.[X]] +\n            (c - a) * u.[Y] * (1 - u.[X]) +\n            (d - b) * u.[X] * u.[Y];\n\n    fbm xy =\n        let shift = [100,100];\n            rot = cis(0.5);   // Rotate to reduce axial bias\n            st = xy;\n            v = 0;\n            a = 0.5;\n        in do\n            for (i in 1..5) (\n                v := v + a * noise st;\n                st := cmul[rot, st] * 2 + shift;\n                a := a * 0.5;\n            );\n        in v;\n\n    smoke [x,y,z,t] =\n        let st = [x,y];\n            q = [ fbm(st), fbm(st + 1) ];\n            r = [ fbm(st + q + [1.7,9.2] + 0.150*t),\n                  fbm(st + q + [8.3,2.8] + 0.126*t) ];\n            f = fbm(st + r);\n            c = lerp[[0.101961,0.619608,0.666667],\n                     [0.666667,0.666667,0.498039],\n                     clamp[f*f*4, 0, 1]];\n        in do\n            c := lerp[c,\n                     [0,0,0.164706],\n                     clamp[mag q, 0, 1]];\n            c := lerp[c,\n                     [0.666667,1,1],\n                     clamp[r.[X], 0, 1]];\n        in (f*f*f+.6*f*f+.5*f)*c;\n\nin\ncircle 2 >> colour smoke",
  },
  {
    group: "curv",
    id: "voronoi",
    name: "Voronoi",
    blurb: "curv/examples/voronoi.curv \u2014 make_texture with nested for loops in a do block.",
    src: "let\n    random2f[x,y] =\n        let t = sin(x+y*1e3);\n        in [frac(t*1e4), frac(t*1e6)];\n\n    voronoi[x,y] =\n        do\n            local p = floor[x,y];\n            local f = frac[x,y];\n            local res = 8;\n            for (i in -1 .. 1)\n                for (j in -1 .. 1) (\n                    local b = [i,j];\n                    local r = b - f + random2f(p+b);\n                    local d = dot[r,r];\n                    res := min[res, d];\n                )\n        in sqrt res;\n\nin\nmake_texture ([x,y,_,_] -> sRGB.grey(voronoi[x,y]))",
  },
  {
    group: "curv",
    id: "circlattice",
    name: "Circle lattice",
    blurb: "curv/examples/circlattice.curv \u2014 repeat_xy, shell, << reverse pipe.",
    src: "let\n    c = repeat_xy [2,2] << shell .2 << colour black << circle 2;\nin\nunion[c,translate[1,1]<<c]",
  },
  {
    group: "curv",
    id: "peppermint",
    name: "Peppermint",
    blurb: "curv/examples/peppermint.curv \u2014 rect{xmin}, repeat_radial, swirl, into intersection, parametric sliders.",
    src: "// demo of 'swirl' transformation\n\nparametric\n    Swirl_Strength: ss :: slider[-10,10] = 4;\n    Swirl_Diameter: sd :: slider[4,40] = 16;\nin\nunion[rect{xmin:0} >> colour red, rect{xmax:0} >> colour(sRGB[1,1,.8])]\n  >> repeat_radial 8\n  >> swirl{strength: ss, d: sd}\n  >> into intersection [circle 8]\n  >> pancake 2",
  },
];
