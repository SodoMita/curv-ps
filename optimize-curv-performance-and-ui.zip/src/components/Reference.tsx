const sections: { title: string; rows: [string, string][] }[] = [
  {
    title: "solve { … }  (the extension)",
    rows: [
      ["var a, b;", "scalar unknowns"],
      ["var p : point;  var b : box;", "point {x,y}; box {x,y,w,h} + derived right, bottom, cx, cy, center, size, pos"],
      ["var cards : box[n];", "list of n unknown boxes (cards.[i])"],
      ["a.right + 10 == b.x;", "required linear constraint (==, <=, >=; chains like 0 <= x <= w)"],
      ["weak: b.w == 200;", "soft constraint: weak | medium | strong, optional weight: weak 3: …"],
      ["minimize (a.w - 1.618*a.h)^2;", "linear or convex-quadratic objective (also maximize)"],
      ["for (i in 0..n-1) { … }", "loops / if (c) { … } generate constraints; name = expr; binds locals"],
      ["L = solve { … };  L.a.w", "returns a record of solved values (+ L.solver.status / time_ms / engine)"],
    ],
  },
  {
    title: "Curv shapes (2D)",
    rows: [
      ["make_shape { dist p = …; colour p = …; bbox = [[x0,y0,0],[x1,y1,0]]; is_2d = true }", "user distance/colour functions compiled to the GPU (SubCurv: let, if, do/local/:=/for/while, vectors, math)"],
      ["make_texture (p -> colour) · colour f shape · texture f shape", "procedural colour functions (p = [x,y,z,t])"],
      ["circle d · square d · rect [w,h] · rect {xmin,xmax,ymin,ymax} · ellipse [w,h] · regular_polygon n · polygon [pts] · half_plane {d,normal} · stroke {d,from,to} · everything · nothing", "primitives"],
      ["union · intersection · difference · complement · smooth k .union · morph t [a,b] · offset d · shell d · lipschitz k", "CSG & distance operators"],
      ["move [x,y] · rotate a · scale k|[sx,sy] · reflect v · repeat_x d · repeat_xy [dx,dy] · repeat_radial n · repeat_mirror_x · swirl {strength,d} · row · into f [..] · show_axes · show_bbox", "transforms"],
      ["sRGB [r,g,b] · sRGB.HSV · sRGB.hue h · sRGB.grey g · webRGB · red/green/blue/…", "colours"],
      ["parametric Name :: slider[lo,hi] = v; … in shape", "sliders (also int_slider, checkbox, scale_picker, colour_picker)"],
      ["phase · cis · cmul · csqr · mag · dot · cross · normalize · lerp [a,b,t] · clamp [x,lo,hi] · smoothstep · mod [a,b] · frac · sign · min/max/sum [..] · bit", "math (vectorised)"],
    ],
  },
  {
    title: "UI shapes (px, origin top-left)",
    rows: [
      ["circle d · rect (w,h) · rrect (w,h) r · ellipse (w,h)", "centred primitives"],
      ["line (p1,p2) th · half_plane n · nothing", ""],
      ["text \"hi\" 14 · text_left \"hi\" 14 · text_width \"hi\" 14", "SDF glyphs; text_width is a number you can constrain on"],
      ["frame b · frame_r r b · at b shape · inset d b · box (x,y,w,h)", "box helpers"],
      ["union [..] · intersection [..] · difference [a,b]", "CSG; union composes colours painter-style"],
      ["smooth_union k [..] · offset r · stroke w", "F-Rep operators on the distance field"],
      ["colour c · opacity a · gradient (c1,c2) (p0,p1) · shadow (dx,dy) blur", "appearance (colours: \"#hex\", (r,g,b), white, accent, …)"],
      ["translate (x,y) · rotate a · scale k · shape >> op", "transforms and Curv's pipe"],
      ["card b · panel b · button b \"label\" · avatar b \"AB\" · progress b t c · toggle b on", "prelude components written in Curv"],
    ],
  },
  {
    title: "Core Curv",
    rows: [
      ["let a = 1; f x = x*2; in …  /  expr where (…)", "definitions"],
      ["x -> x+1 · [a,b] -> a*b · f a b (curried) · a >> f · f << a", "functions & pipes"],
      ["do local x = 0; for (i in 1..n until done) x := x + i; in x", "imperative blocks (compiled to shader loops inside make_shape)"],
      ["[for (i in 0..9) if (i%2==0) i*i] · 1..10 by 2 · 0..<n", "comprehensions & ranges"],
      ["{a: 1, b: 2} · r.a · list.[i] · count · sum · map · strcat", "records, lists"],
      ["parent.width/height · time · mouse.x/y/pos", "live inputs: re-evaluated on resize / every frame / on move"],
    ],
  },
];

export function Reference() {
  return (
    <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-4">
      {sections.map((s) => (
        <div key={s.title}>
          <h4 className="mb-2 text-[11px] font-semibold uppercase tracking-[0.14em] text-muted">{s.title}</h4>
          <dl className="space-y-1.5">
            {s.rows.map(([k, v]) => (
              <div key={k} className="rounded-md border border-line/60 bg-surface/50 px-3 py-1.5">
                <dt className="font-mono text-[11.5px] text-accent-2">{k}</dt>
                {v && <dd className="text-[11.5px] text-muted">{v}</dd>}
              </div>
            ))}
          </dl>
        </div>
      ))}
    </div>
  );
}
