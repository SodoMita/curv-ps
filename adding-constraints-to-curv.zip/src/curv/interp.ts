// Tree-walking evaluator for extended Curv.  Shape values build an F-Rep
// tree (shapes.ts); `solve { ... }` blocks compile to a psolve problem.
import { parse, CurvError, type Expr, type Def, type Pat, type ListItem, type Stmt } from "./parser";
import { Lin, Quad, Problem, STRENGTH, type Rel } from "../psolve/constraints";
import { Shape, type SNode, type RGBA } from "./shapes";
import { measureText, type Atlas } from "../gpu/atlas";
import { PRELUDE } from "./prelude";

export class Rec { constructor(public f: Map<string, Value> = new Map()) {} get(k: string) { return this.f.get(k); } }
export class Fn { constructor(public name: string, public call: (arg: Value, line?: number) => Value) {} }
export type Value = number | string | boolean | null | Value[] | Rec | Fn | Shape | Lin | Quad;

export interface SolveTrace {
  line: number; engine: string; status: string; ok: boolean; timeMs: number; iterations: number;
  nVars: number; nCons: number; eliminated: number; objective: number; violations: { label: string; amount: number }[];
  values: { name: string; value: string }[];
  boxes: { x: number; y: number; w: number; h: number }[];
}
export interface EvalResult { shape: SNode | null; traces: SolveTrace[]; usesTime: boolean; usesMouse: boolean; value: Value }
export interface Inputs { width: number; height: number; time: number; mouse: { x: number; y: number; down: boolean } }

class Env {
  constructor(public vars: Map<string, Value> = new Map(), public parent: Env | null = null) {}
  lookup(n: string): Value | undefined { let e: Env | null = this; while (e) { if (e.vars.has(n)) return e.vars.get(n); e = e.parent; } return undefined; }
  child() { return new Env(new Map(), this); }
}

// ---------- helpers ----------
const err = (m: string, line?: number) => new CurvError(m, line);
const isNum = (v: Value): v is number => typeof v === "number";
const isList = (v: Value): v is Value[] => Array.isArray(v);
const isAff = (v: Value): v is number | Lin => typeof v === "number" || v instanceof Lin;
const toLin = (v: number | Lin) => (typeof v === "number" ? Lin.const(v) : v);
const toQuad = (v: number | Lin | Quad) => (v instanceof Quad ? v : Quad.fromLin(toLin(v)));

export function typeName(v: Value): string {
  if (v === null) return "null"; if (isNum(v)) return "number"; if (typeof v === "string") return "string";
  if (typeof v === "boolean") return "bool"; if (isList(v)) return "list"; if (v instanceof Rec) return "record";
  if (v instanceof Fn) return "function"; if (v instanceof Shape) return "shape"; if (v instanceof Lin) return "linear expression";
  return "quadratic expression";
}
export function show(v: Value, depth = 0): string {
  if (v === null) return "null"; if (isNum(v)) return Number.isInteger(v) ? String(v) : v.toFixed(3).replace(/\.?0+$/, "");
  if (typeof v === "string") return JSON.stringify(v); if (typeof v === "boolean") return String(v);
  if (isList(v)) return depth > 2 ? "[…]" : "[" + v.map((x) => show(x, depth + 1)).join(", ") + "]";
  if (v instanceof Rec) return depth > 2 ? "{…}" : "{" + [...v.f].map(([k, x]) => `${k}: ${show(x, depth + 1)}`).join(", ") + "}";
  if (v instanceof Fn) return `<function ${v.name}>`; if (v instanceof Shape) return "<shape>";
  if (v instanceof Lin) return "<linear expr>"; return "<quadratic expr>";
}

function arith(op: string, a: Value, b: Value, line?: number): Value {
  if (isList(a) && isList(b)) { if (a.length !== b.length) throw err(`Vector length mismatch (${a.length} vs ${b.length})`, line); return a.map((x, i) => arith(op, x, b[i], line)); }
  if (isList(a)) return a.map((x) => arith(op, x, b, line));
  if (isList(b)) return b.map((x) => arith(op, a, x, line));
  if (isNum(a) && isNum(b)) {
    switch (op) { case "+": return a + b; case "-": return a - b; case "*": return a * b; case "/": return a / b; case "^": return Math.pow(a, b); case "%": return ((a % b) + b) % b; }
  }
  if (op === "+" && typeof a === "string" && typeof b === "string") return a + b;
  if ((isAff(a) || a instanceof Quad) && (isAff(b) || b instanceof Quad)) {
    if (a instanceof Quad || b instanceof Quad) {
      const qa = toQuad(a), qb = toQuad(b);
      if (op === "+") return qa.add(qb); if (op === "-") return qa.add(qb.scale(-1));
      if (op === "*" && isNum(b)) return qa.scale(b); if (op === "*" && isNum(a)) return qb.scale(a);
      if (op === "/" && isNum(b)) return qa.scale(1 / b);
      throw err(`Operator '${op}' would make the objective non-quadratic`, line);
    }
    const la = toLin(a as number | Lin), lb = toLin(b as number | Lin);
    switch (op) {
      case "+": return la.add(lb); case "-": return la.sub(lb);
      case "*": if (isNum(b)) return la.scale(b); if (isNum(a)) return lb.scale(a); return Quad.mul(la, lb);
      case "/": if (isNum(b)) return la.scale(1 / b); throw err("Cannot divide by a solver variable (non-linear)", line);
      case "^": if (b === 2) return Quad.mul(la, la); throw err("Only ^2 is allowed on solver variables (convex quadratic)", line);
    }
  }
  throw err(`Cannot apply '${op}' to ${typeName(a)} and ${typeName(b)}`, line);
}
function truthy(v: Value, line?: number): boolean { if (typeof v === "boolean") return v; throw err(`Expected a boolean, got ${typeName(v)}`, line); }
function equalV(a: Value, b: Value): boolean {
  if (isList(a) && isList(b)) return a.length === b.length && a.every((x, i) => equalV(x, b[i]));
  return a === b;
}
export function num(v: Value, what = "number", line?: number): number { if (isNum(v)) return v; throw err(`Expected ${what}, got ${typeName(v)}`, line); }
function vec2(v: Value, what = "a point (x,y)", line?: number): [number, number] { if (isList(v) && v.length === 2 && isNum(v[0]) && isNum(v[1])) return [v[0], v[1]]; if (isNum(v)) return [v, v]; throw err(`Expected ${what}, got ${show(v)}`, line); }
function shape(v: Value, line?: number): SNode { if (v instanceof Shape) return v.node; throw err(`Expected a shape, got ${typeName(v)}`, line); }
function shapes(v: Value, line?: number): SNode[] { if (isList(v)) return v.map((x) => shape(x, line)); return [shape(v, line)]; }
function rec(v: Value, line?: number): Rec { if (v instanceof Rec) return v; throw err(`Expected a record, got ${typeName(v)}`, line); }
const NAMED: Record<string, string> = { white: "#ffffff", black: "#000000", red: "#ef4444", green: "#22c55e", blue: "#3b82f6", yellow: "#eab308", orange: "#f97316", purple: "#a855f7", pink: "#ec4899", cyan: "#06b6d4", gray: "#6b7280", grey: "#6b7280", transparent: "#00000000" };
export function colour(v: Value, line?: number): RGBA {
  if (typeof v === "string") {
    const s = NAMED[v] ?? v; const m = /^#([0-9a-f]{3,8})$/i.exec(s);
    if (!m) throw err(`Unknown colour '${v}'`, line);
    let h = m[1]; if (h.length === 3 || h.length === 4) h = h.split("").map((c) => c + c).join("");
    const n = parseInt(h, 16);
    if (h.length === 6) return [((n >> 16) & 255) / 255, ((n >> 8) & 255) / 255, (n & 255) / 255, 1];
    return [((n >>> 24) & 255) / 255, ((n >> 16) & 255) / 255, ((n >> 8) & 255) / 255, (n & 255) / 255];
  }
  if (isList(v) && (v.length === 3 || v.length === 4) && v.every(isNum)) return [v[0], v[1], v[2], v.length === 4 ? v[3] : 1] as RGBA;
  throw err(`Expected a colour ("#rrggbb" or (r,g,b)), got ${show(v)}`, line);
}
function boxOf(v: Value, line?: number): { x: number; y: number; w: number; h: number } {
  const r = rec(v, line); const g = (k: string) => num(r.get(k) ?? 0, `box field ${k}`, line);
  return { x: g("x"), y: g("y"), w: g("w"), h: g("h") };
}
const S = (n: SNode) => new Shape(n);
const fn1 = (name: string, f: (a: Value, line?: number) => Value) => new Fn(name, f);
const fn2 = (name: string, f: (a: Value, b: Value, line?: number) => Value) => new Fn(name, (a, l) => new Fn(name + "'", (b, l2) => f(a, b, l2 ?? l)));
const fn3 = (name: string, f: (a: Value, b: Value, c: Value, line?: number) => Value) => new Fn(name, (a) => new Fn(name, (b) => new Fn(name, (c, l) => f(a, b, c, l))));
const mathf = (name: string, f: (x: number) => number) => fn1(name, (a, l) => (isList(a) ? a.map((x) => f(num(x, "number", l))) : f(num(a, "number", l))));

export function makeBoxRec(x: number | Lin, y: number | Lin, w: number | Lin, h: number | Lin): Rec {
  const add = (a: number | Lin, b: number | Lin) => arith("+", a, b) as number | Lin;
  const half = (a: number | Lin) => arith("*", a, 0.5) as number | Lin;
  return new Rec(new Map<string, Value>([
    ["x", x], ["y", y], ["w", w], ["h", h], ["left", x], ["top", y],
    ["right", add(x, w)], ["bottom", add(y, h)], ["cx", add(x, half(w))], ["cy", add(y, half(h))],
    ["center", [add(x, half(w)), add(y, half(h))]], ["size", [w, h]], ["pos", [x, y]],
  ]));
}

// ---------- interpreter ----------
export class Interp {
  traces: SolveTrace[] = []; usesTime = false; usesMouse = false;
  constructor(public atlas: Atlas, public inputs: Inputs) {}

  builtins(): Env {
    const env = new Env();
    const b = (name: string, v: Value) => env.vars.set(name, v);
    // --- math
    b("pi", Math.PI); b("tau", Math.PI * 2); b("deg", Math.PI / 180); b("inf", Infinity);
    for (const [n, hex] of Object.entries(NAMED)) b(n, hex);
    for (const [n, f] of Object.entries({ sin: Math.sin, cos: Math.cos, tan: Math.tan, sqrt: Math.sqrt, abs: Math.abs, floor: Math.floor, ceil: Math.ceil, round: Math.round, exp: Math.exp, log: Math.log, sign: Math.sign })) b(n, mathf(n, f));
    b("min", fn1("min", (a, l) => Math.min(...(isList(a) ? a : [a]).map((x) => num(x, "number", l)))));
    b("max", fn1("max", (a, l) => Math.max(...(isList(a) ? a : [a]).map((x) => num(x, "number", l)))));
    b("clamp", fn1("clamp", (a, l) => { const [x, lo, hi] = (isList(a) ? a : []).map((v) => num(v, "number", l)); return Math.min(hi, Math.max(lo, x)); }));
    b("lerp", fn3("lerp", (a, c, t, l) => arith("+", a, arith("*", arith("-", c, a, l), t, l), l)));
    b("mag", fn1("mag", (a, l) => Math.hypot(...(isList(a) ? a : [a]).map((x) => num(x, "number", l)))));
    b("mod", fn2("mod", (a, c, l) => arith("%", a, c, l)));
    b("atan2", fn1("atan2", (a, l) => { const [y, x] = vec2(a, "(y,x)", l); return Math.atan2(y, x); }));
    // --- lists / strings
    b("count", fn1("count", (a, l) => (isList(a) ? a.length : typeof a === "string" ? a.length : (() => { throw err("count expects a list", l); })())));
    b("sum", fn1("sum", (a, l) => (isList(a) ? a.reduce<Value>((s, x) => arith("+", s, x, l), 0) : (() => { throw err("sum expects a list", l); })())));
    b("map", fn2("map", (f, a, l) => { if (!(f instanceof Fn) || !isList(a)) throw err("map expects a function and a list", l); return a.map((x) => f.call(x, l)); }));
    b("filter", fn2("filter", (f, a, l) => { if (!(f instanceof Fn) || !isList(a)) throw err("filter expects a function and a list", l); return a.filter((x) => truthy(f.call(x, l), l)); }));
    b("reverse", fn1("reverse", (a, l) => { if (!isList(a)) throw err("reverse expects a list", l); return [...a].reverse(); }));
    b("concat", fn1("concat", (a, l) => { if (!isList(a)) throw err("concat expects a list of lists", l); return a.flatMap((x) => (isList(x) ? x : [x])); }));
    b("indices", fn1("indices", (a, l) => { if (!isList(a)) throw err("indices expects a list", l); return a.map((_, i) => i); }));
    b("str", fn1("str", (a) => (typeof a === "string" ? a : show(a))));
    b("strcat", fn1("strcat", (a) => (isList(a) ? a : [a]).map((x) => (typeof x === "string" ? x : show(x))).join("")));
    b("fields", fn1("fields", (a, l) => [...rec(a, l).f.keys()]));
    b("text_width", fn2("text_width", (t, s, l) => measureText(this.atlas, typeof t === "string" ? t : show(t), num(s, "font size", l))));
    // --- shapes: primitives (UI coordinates: origin top-left, y down, pixels)
    b("nothing", S({ k: "nothing" }));
    b("circle", fn1("circle", (d, l) => S({ k: "circle", r: num(d, "diameter", l) / 2 })));
    b("disc", fn1("disc", (d, l) => S({ k: "circle", r: num(d, "diameter", l) / 2 })));
    b("ellipse", fn1("ellipse", (v, l) => { const [w, h] = vec2(v, "(w,h)", l); return S({ k: "ellipse", a: w, b: h }); }));
    b("rect", fn1("rect", (v, l) => { const [w, h] = vec2(v, "(w,h)", l); return S({ k: "rect", w, h, r: 0 }); }));
    b("rrect", fn2("rrect", (v, r, l) => { const [w, h] = vec2(v, "(w,h)", l); return S({ k: "rect", w, h, r: num(r, "corner radius", l) }); }));
    b("line", fn2("line", (pts, th, l) => { if (!isList(pts) || pts.length !== 2) throw err("line expects (p1,p2)", l); const [x1, y1] = vec2(pts[0], "point", l), [x2, y2] = vec2(pts[1], "point", l); return S({ k: "seg", x1, y1, x2, y2, th: num(th, "thickness", l) }); }));
    b("half_plane", fn1("half_plane", (v, l) => { const [nx, ny] = vec2(v, "normal", l); return S({ k: "half", nx, ny }); }));
    b("text", fn2("text", (t, s, l) => S({ k: "text", text: typeof t === "string" ? t : show(t), size: num(s, "font size", l), align: "center" })));
    b("text_left", fn2("text_left", (t, s, l) => S({ k: "text", text: typeof t === "string" ? t : show(t), size: num(s, "font size", l), align: "left" })));
    // box helpers (a box is a record {x,y,w,h}, e.g. a solved layout variable)
    b("frame", fn1("frame", (v, l) => { const bx = boxOf(v, l); return S({ k: "xform", tx: bx.x + bx.w / 2, ty: bx.y + bx.h / 2, rot: 0, sc: 1, s: { k: "rect", w: bx.w, h: bx.h, r: 0 } }); }));
    b("frame_r", fn2("frame_r", (r, v, l) => { const bx = boxOf(v, l); return S({ k: "xform", tx: bx.x + bx.w / 2, ty: bx.y + bx.h / 2, rot: 0, sc: 1, s: { k: "rect", w: bx.w, h: bx.h, r: num(r, "corner radius", l) } }); }));
    b("at", fn2("at", (v, s, l) => { const bx = boxOf(v, l); return S({ k: "xform", tx: bx.x + bx.w / 2, ty: bx.y + bx.h / 2, rot: 0, sc: 1, s: shape(s, l) }); }));
    b("box", fn1("box", (v, l) => { if (!isList(v) || v.length !== 4) throw err("box expects (x,y,w,h)", l); const [x, y, w, h] = v.map((n) => num(n, "number", l)); return makeBoxRec(x, y, w, h); }));
    b("inset", fn2("inset", (d, v, l) => { const bx = boxOf(v, l); const k = num(d, "inset", l); return makeBoxRec(bx.x + k, bx.y + k, bx.w - 2 * k, bx.h - 2 * k); }));
    // --- shape operators
    b("union", fn1("union", (v, l) => S({ k: "union", kids: shapes(v, l) })));
    b("intersection", fn1("intersection", (v, l) => S({ k: "inter", kids: shapes(v, l) })));
    b("difference", fn1("difference", (v, l) => { const k = shapes(v, l); if (k.length < 2) throw err("difference expects [a, b]", l); return S({ k: "diff", a: k[0], b: k.length === 2 ? k[1] : { k: "union", kids: k.slice(1) } }); }));
    b("smooth_union", fn2("smooth_union", (k, v, l) => S({ k: "sunion", s: num(k, "blend radius", l), kids: shapes(v, l) })));
    b("smooth_intersection", fn2("smooth_intersection", (k, v, l) => S({ k: "sinter", s: num(k, "blend radius", l), kids: shapes(v, l) })));
    b("offset", fn2("offset", (r, s, l) => S({ k: "round", r: num(r, "offset", l), s: shape(s, l) })));
    b("stroke", fn2("stroke", (w, s, l) => S({ k: "stroke", w: num(w, "stroke width", l), s: shape(s, l) })));
    const col = fn2("colour", (c, s, l) => S({ k: "colour", c: colour(c, l), s: shape(s, l) }));
    b("colour", col); b("color", col);
    b("opacity", fn2("opacity", (a, s, l) => S({ k: "opacity", a: num(a, "opacity", l), s: shape(s, l) })));
    b("gradient", fn3("gradient", (cs, pts, s, l) => { if (!isList(cs) || cs.length !== 2 || !isList(pts) || pts.length !== 2) throw err("gradient expects (c1,c2) (p0,p1) shape", l); const [x0, y0] = vec2(pts[0], "point", l), [x1, y1] = vec2(pts[1], "point", l); return S({ k: "grad", c1: colour(cs[0], l), c2: colour(cs[1], l), x0, y0, x1, y1, s: shape(s, l) }); }));
    b("shadow", fn3("shadow", (o, bl, s, l) => { const [dx, dy] = vec2(o, "offset", l); return S({ k: "shadow", dx, dy, blur: num(bl, "blur", l), a: 0.45, s: shape(s, l) }); }));
    b("translate", fn2("translate", (v, s, l) => { const [tx, ty] = vec2(v, "offset", l); return S({ k: "xform", tx, ty, rot: 0, sc: 1, s: shape(s, l) }); }));
    b("move", env.vars.get("translate")!);
    b("rotate", fn2("rotate", (a, s, l) => S({ k: "xform", tx: 0, ty: 0, rot: num(a, "angle", l), sc: 1, s: shape(s, l) })));
    b("scale", fn2("scale", (k, s, l) => S({ k: "xform", tx: 0, ty: 0, rot: 0, sc: num(k, "scale factor", l), s: shape(s, l) })));
    // --- environment
    const parent = makeBoxRec(0, 0, this.inputs.width, this.inputs.height);
    parent.f.set("width", this.inputs.width); parent.f.set("height", this.inputs.height);
    b("parent", parent);
    b("time", this.inputs.time);
    b("mouse", new Rec(new Map<string, Value>([["x", this.inputs.mouse.x], ["y", this.inputs.mouse.y], ["down", this.inputs.mouse.down], ["pos", [this.inputs.mouse.x, this.inputs.mouse.y]]])));
    return env;
  }

  run(src: string): EvalResult {
    const base = this.builtins();
    const preludeEnv = base.child();
    const pre = parse("{" + PRELUDE + "}");
    if (pre.k === "rec") this.bindDefs(pre.defs, preludeEnv);
    const ast = parse(src);
    const value = this.eval(ast, preludeEnv.child());
    let node: SNode | null = null;
    if (value instanceof Shape) node = value.node;
    else if (isList(value) && value.every((v) => v instanceof Shape)) node = { k: "union", kids: value.map((v) => (v as Shape).node) };
    return { shape: node, traces: this.traces, usesTime: this.usesTime, usesMouse: this.usesMouse, value };
  }

  bindPat(p: Pat, v: Value, env: Env, line?: number) {
    if (p.k === "id") { env.vars.set(p.name, v); return; }
    if (p.k === "list") { if (!isList(v) || v.length !== p.items.length) throw err(`Pattern expects a list of ${p.items.length}, got ${show(v)}`, line); p.items.forEach((q, i) => this.bindPat(q, v[i], env, line)); return; }
    const r = rec(v, line); for (const n of p.names) { if (!r.f.has(n)) throw err(`Record has no field '${n}'`, line); env.vars.set(n, r.f.get(n)!); }
  }
  makeClosure(params: Pat[], body: Expr, env: Env, name: string): Fn {
    const mk = (i: number, e: Env): Fn => new Fn(name, (arg, line) => { const e2 = e.child(); this.bindPat(params[i], arg, e2, line); return i + 1 < params.length ? mk(i + 1, e2) : this.eval(body, e2); });
    return mk(0, env);
  }
  bindDefs(defs: Def[], env: Env) {
    // functions first (recursion-friendly), then values in order
    for (const d of defs) if (d.params.length > 0 || d.body.k === "lambda") {
      const v = d.params.length > 0 ? this.makeClosure(d.params, d.body, env, d.pat.k === "id" ? d.pat.name : "fn") : this.eval(d.body, env);
      this.bindPat(d.pat, v, env, d.line);
    }
    for (const d of defs) if (!(d.params.length > 0 || d.body.k === "lambda")) this.bindPat(d.pat, this.eval(d.body, env), env, d.line);
  }
  listItems(items: ListItem[], env: Env, out: Value[]) {
    for (const it of items) this.listItem(it, env, out);
  }
  listItem(it: ListItem, env: Env, out: Value[]) {
    switch (it.k) {
      case "expr": out.push(this.eval(it.e, env)); break;
      case "spread": { const v = this.eval(it.e, env); if (!isList(v)) throw err("Can only spread a list"); out.push(...v); break; }
      case "for": { const l = this.eval(it.iter, env); if (!isList(l)) throw err("for expects a list"); for (const x of l) { const e2 = env.child(); this.bindPat(it.pat, x, e2); this.listItem(it.body, e2, out); } break; }
      case "if": if (truthy(this.eval(it.cond, env))) this.listItem(it.then, env, out); else if (it.else) this.listItem(it.else, env, out); break;
    }
  }

  eval(e: Expr, env: Env): Value {
    switch (e.k) {
      case "num": return e.v; case "str": return e.v; case "bool": return e.v; case "null": return null;
      case "id": {
        if (e.name === "time") this.usesTime = true; if (e.name === "mouse") this.usesMouse = true;
        const v = env.lookup(e.name); if (v === undefined) throw err(`Unknown identifier '${e.name}'`, e.line); return v;
      }
      case "list": { const out: Value[] = []; this.listItems(e.items, env, out); return out; }
      case "rec": {
        const e2 = env.child(); this.bindDefs(e.defs, e2);
        const r = new Rec(); for (const [k, v] of e2.vars) r.f.set(k, v);
        for (const f of e.fields) r.f.set(f.name, this.eval(f.e, e2)); return r;
      }
      case "let": { const e2 = env.child(); this.bindDefs(e.defs, e2); return this.eval(e.body, e2); }
      case "if": return truthy(this.eval(e.cond, env)) ? this.eval(e.then, env) : this.eval(e.else, env);
      case "lambda": return this.makeClosure(e.params, e.body, env, "λ");
      case "call": {
        const f = this.eval(e.fn, env); const a = this.eval(e.arg, env);
        if (f instanceof Fn) return f.call(a, e.line);
        if (isList(f) || f instanceof Rec) return this.index(f, a, e.line);
        throw err(`Cannot call a ${typeName(f)}`, e.line);
      }
      case "index": return this.index(this.eval(e.e, env), this.eval(e.idx, env), e.line);
      case "field": {
        const v = this.eval(e.e, env);
        if (v instanceof Rec) { const f = v.get(e.name); if (f === undefined) throw err(`Record has no field '${e.name}' (fields: ${[...v.f.keys()].join(", ")})`, e.line); return f; }
        throw err(`Cannot take field '.${e.name}' of a ${typeName(v)}`, e.line);
      }
      case "un": { const v = this.eval(e.e, env); if (e.op === "!") return !truthy(v, e.line); return arith("*", v, -1, e.line); }
      case "bin": {
        if (e.op === "&&") return truthy(this.eval(e.a, env), e.line) && truthy(this.eval(e.b, env), e.line);
        if (e.op === "||") return truthy(this.eval(e.a, env), e.line) || truthy(this.eval(e.b, env), e.line);
        return arith(e.op, this.eval(e.a, env), this.eval(e.b, env), e.line);
      }
      case "cmp": {
        const vals = e.args.map((a) => this.eval(a, env));
        for (let i = 0; i < e.ops.length; i++) {
          const a = vals[i], b = vals[i + 1], op = e.ops[i];
          if (a instanceof Lin || b instanceof Lin) throw err("Constraints on solver variables are only allowed as statements inside solve { }", e.line);
          let r: boolean;
          if (op === "==") r = equalV(a, b); else if (op === "!=") r = !equalV(a, b);
          else { const x = num(a, "number", e.line), y = num(b, "number", e.line); r = op === "<" ? x < y : op === "<=" ? x <= y : op === ">" ? x > y : x >= y; }
          if (!r) return false;
        }
        return true;
      }
      case "range": {
        const a = num(this.eval(e.a, env), "range start"), b = num(this.eval(e.b, env), "range end"), s = e.step ? num(this.eval(e.step, env), "range step") : 1;
        const out: number[] = []; if (s === 0) throw err("range step cannot be 0"); for (let x = a; s > 0 ? x <= b + 1e-9 : x >= b - 1e-9; x += s) { out.push(x); if (out.length > 100000) throw err("range too large"); } return out;
      }
      case "solve": return this.solve(e.stmts, env, e.line);
    }
  }
  index(c: Value, i: Value, line?: number): Value {
    if (isList(i) && i.length === 1) i = i[0];
    if (isList(c)) {
      if (isList(i)) return i.map((x) => this.index(c, x, line));
      const k = num(i, "index", line); if (k < 0 || k >= c.length || !Number.isInteger(k)) throw err(`Index ${k} out of range (list has ${c.length})`, line); return c[k];
    }
    if (c instanceof Rec) { if (typeof i !== "string") throw err("Record index must be a string", line); const v = c.get(i); if (v === undefined) throw err(`Record has no field '${i}'`, line); return v; }
    throw err(`Cannot index a ${typeName(c)}`, line);
  }

  // ---------- solve { } ----------
  solve(stmts: Stmt[], outer: Env, line: number): Value {
    const prob = new Problem(); const env = outer.child();
    const declared: { name: string; value: Value }[] = [];
    let nCons = 0;
    const mkVar = (name: string, type: string): Value => {
      if (type === "num") return Lin.v(prob.newVar(name));
      if (type === "point") return [Lin.v(prob.newVar(name + ".x")), Lin.v(prob.newVar(name + ".y"))];
      if (type === "box") return makeBoxRec(Lin.v(prob.newVar(name + ".x")), Lin.v(prob.newVar(name + ".y")), Lin.v(prob.newVar(name + ".w")), Lin.v(prob.newVar(name + ".h")));
      throw err(`Unknown variable type '${type}' (use num, point, box, or type[n])`, line);
    };
    const addCons = (a: Value, b: Value, op: string, weight: number, label: string, ln: number) => {
      if (isList(a) && isList(b)) { if (a.length !== b.length) throw err("Constraint vector length mismatch", ln); a.forEach((x, i) => addCons(x, b[i], op, weight, label, ln)); return; }
      if (isList(a)) { a.forEach((x) => addCons(x, b, op, weight, label, ln)); return; }
      if (isList(b)) { b.forEach((x) => addCons(a, x, op, weight, label, ln)); return; }
      if (a instanceof Rec && b instanceof Rec) { for (const k of ["x", "y", "w", "h"]) if (a.f.has(k) && b.f.has(k)) addCons(a.get(k)!, b.get(k)!, op, weight, label + "." + k, ln); return; }
      if (!isAff(a) || !isAff(b)) throw err(`Constraints must be linear in solver variables (got ${typeName(a)} ${op} ${typeName(b)})`, ln);
      const lin = toLin(a).sub(toLin(b));
      const rel: Rel = op === "==" ? "=" : op === "<=" || op === "<" ? "<" : op === ">=" || op === ">" ? ">" : (() => { throw err("'!=' is not a convex constraint", ln); })();
      if (lin.isConst()) { const v = lin.c; const ok = rel === "=" ? Math.abs(v) < 1e-9 : rel === "<" ? v <= 1e-9 : v >= -1e-9; if (!ok && weight === Infinity) throw err(`Constraint on line ${ln} is constant and false`, ln); return; }
      prob.addConstraint({ lin, rel, weight, label }); nCons++;
    };
    const exec = (ss: Stmt[], env: Env) => {
      for (const s of ss) {
        switch (s.k) {
          case "var": {
            const cnt = s.count ? num(this.eval(s.count, env), "count", s.line) : undefined;
            for (const n of s.names) { const v: Value = cnt === undefined ? mkVar(n, s.type) : Array.from({ length: cnt }, (_, i) => mkVar(`${n}[${i}]`, s.type)); env.vars.set(n, v); declared.push({ name: n, value: v }); }
            break;
          }
          case "def": this.bindDefs([s.def], env); break;
          case "cons": {
            if (s.e.k !== "cmp") throw err("Expected a constraint like a == b, a <= b or a >= b", s.line);
            const w = s.weight ? num(this.eval(s.weight, env), "weight", s.line) : 1;
            const weight = s.strength === "required" ? Infinity : STRENGTH[s.strength] * w;
            const vals = s.e.args.map((a) => this.eval(a, env));
            for (let i = 0; i < s.e.ops.length; i++) addCons(vals[i], vals[i + 1], s.e.ops[i], weight, `${s.strength} line ${s.line}`, s.line);
            break;
          }
          case "obj": {
            const v = this.eval(s.e, env);
            if (!(isAff(v) || v instanceof Quad)) throw err("Objective must be a linear or quadratic expression", s.line);
            prob.minimize(s.sense === "minimize" ? toQuad(v) : toQuad(v).scale(-1)); break;
          }
          case "for": { const l = this.eval(s.iter, env); if (!isList(l)) throw err("for expects a list", s.line); for (const x of l) { const e2 = env.child(); this.bindPat(s.pat, x, e2, s.line); exec(s.body, e2); } break; }
          case "if": if (truthy(this.eval(s.cond, env), s.line)) exec(s.body, env.child()); else if (s.else) exec(s.else, env.child()); break;
        }
      }
    };
    exec(stmts, env);
    const res = prob.solve();
    const subst = (v: Value): Value => {
      if (v instanceof Lin) return res.ok ? v.eval(res.values) : 0;
      if (isList(v)) return v.map(subst);
      if (v instanceof Rec) { const r = new Rec(); for (const [k, x] of v.f) r.f.set(k, subst(x)); return r; }
      return v;
    };
    const out = new Rec();
    const shown: { name: string; value: string }[] = [];
    const boxes: { x: number; y: number; w: number; h: number }[] = [];
    const collect = (v: Value) => {
      if (isList(v)) v.forEach(collect);
      else if (v instanceof Rec && ["x", "y", "w", "h"].every((k) => isNum(v.get(k) ?? null))) boxes.push({ x: v.get("x") as number, y: v.get("y") as number, w: v.get("w") as number, h: v.get("h") as number });
    };
    for (const d of declared) {
      const v = subst(d.value); out.f.set(d.name, v); collect(v);
      if (isList(v) && v.length > 0 && (v[0] instanceof Rec || isList(v[0]))) v.slice(0, 16).forEach((x, i) => shown.push({ name: `${d.name}[${i}]`, value: showSolved(x) }));
      else shown.push({ name: d.name, value: showSolved(v) });
    }
    out.f.set("solver", new Rec(new Map<string, Value>([["status", res.statusText], ["ok", res.ok], ["engine", res.engine], ["objective", res.objective], ["iterations", res.iterations], ["time_ms", res.timeMs]])));
    this.traces.push({ line, engine: res.reducedVars === 0 ? "presolve" : res.engine, status: res.statusText, ok: res.ok, timeMs: res.timeMs, iterations: res.iterations, nVars: prob.names.length, nCons, eliminated: res.eliminated ?? 0, objective: res.objective, violations: res.violations, values: shown, boxes });
    if (!res.ok) throw err(`solve on line ${line} failed: ${res.statusText} (${res.engine})`, line);
    return out;
  }
}
function showSolved(v: Value): string {
  const f = (n: number) => (Math.abs(n) < 5e-4 ? "0" : Number.isInteger(n) ? String(n) : n.toFixed(2).replace(/\.?0+$/, ""));
  if (isNum(v)) return f(v);
  if (v instanceof Rec) { const g = (k: string) => f(v.get(k) as number); return v.f.has("w") ? `x ${g("x")}  y ${g("y")}  w ${g("w")}  h ${g("h")}` : [...v.f].map(([k, x]) => `${k} ${showSolved(x)}`).join("  "); }
  if (isList(v)) return v.length <= 4 && v.every(isNum) ? "(" + v.map(f).join(", ") + ")" : `[${v.length} items]`;
  return show(v);
}
