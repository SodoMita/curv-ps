// F-Rep shape tree (what Curv shape values evaluate to) and its compilation
// into a postfix "SDF program" executed per-pixel by the WebGPU shader
// (and by the CPU fallback).  One instruction = 3 vec4 = 12 floats.
import { type Atlas, CELL, FONT_PX, GLYPH_PAD, BASELINE, ATLAS_COLS, ATLAS_ROWS, advanceOf } from "../gpu/atlas";

export const OP = {
  END: 0, CIRCLE: 1, RECT: 2, SEG: 3, ELLIPSE: 4, NOTHING: 5, GLYPH: 6, HALF: 7,
  UNION: 10, INTER: 11, DIFF: 12, SUNION: 13, SINTER: 14,
  ROUND: 20, STROKE: 21, COLOUR: 22, GRAD: 23, OPACITY: 24, SHADOW: 25,
  PUSH_XF: 30, POP_XF: 31,
} as const;
export const INSTR_FLOATS = 12;

export type RGBA = [number, number, number, number];
export type SNode =
  | { k: "circle"; r: number } | { k: "rect"; w: number; h: number; r: number }
  | { k: "seg"; x1: number; y1: number; x2: number; y2: number; th: number }
  | { k: "ellipse"; a: number; b: number } | { k: "nothing" } | { k: "half"; nx: number; ny: number }
  | { k: "text"; text: string; size: number; align: "center" | "left" }
  | { k: "union"; kids: SNode[] } | { k: "inter"; kids: SNode[] } | { k: "diff"; a: SNode; b: SNode }
  | { k: "sunion"; s: number; kids: SNode[] } | { k: "sinter"; s: number; kids: SNode[] }
  | { k: "round"; r: number; s: SNode } | { k: "stroke"; w: number; s: SNode }
  | { k: "colour"; c: RGBA; s: SNode } | { k: "opacity"; a: number; s: SNode }
  | { k: "grad"; c1: RGBA; c2: RGBA; x0: number; y0: number; x1: number; y1: number; s: SNode }
  | { k: "shadow"; dx: number; dy: number; blur: number; a: number; s: SNode }
  | { k: "xform"; tx: number; ty: number; rot: number; sc: number; s: SNode };

export class Shape {
  constructor(public node: SNode) {}
}

export function compileProgram(root: SNode, atlas: Atlas, maxInstr = 6000): Float32Array {
  const out: number[] = [];
  const emit = (...v: number[]) => { while (v.length < INSTR_FLOATS) v.push(0); out.push(...v); };
  const walk = (n: SNode) => {
    if (out.length / INSTR_FLOATS > maxInstr) throw new Error("Shape too complex for the GPU program buffer");
    switch (n.k) {
      case "circle": emit(OP.CIRCLE, n.r); break;
      case "rect": emit(OP.RECT, n.w / 2, n.h / 2, Math.min(n.r, n.w / 2, n.h / 2)); break;
      case "seg": emit(OP.SEG, n.x1, n.y1, n.x2, n.y2, n.th / 2); break;
      case "ellipse": emit(OP.ELLIPSE, n.a / 2, n.b / 2); break;
      case "nothing": emit(OP.NOTHING); break;
      case "half": emit(OP.HALF, n.nx, n.ny); break;
      case "text": {
        const s = n.size / FONT_PX; let total = 0;
        for (const ch of n.text) total += advanceOf(atlas, ch.charCodeAt(0)) * s;
        let x = n.align === "center" ? -total / 2 : 0; const baseY = n.align === "center" ? n.size * 0.36 : 0;
        let first = true;
        for (const ch of n.text) {
          const code = ch.charCodeAt(0); const adv = advanceOf(atlas, code) * s;
          if (code !== 32) {
            const [cc, cr] = atlas.cell(code);
            const u0 = cc / ATLAS_COLS, v0 = cr / ATLAS_ROWS, u1 = (cc + 1) / ATLAS_COLS, v1 = (cr + 1) / ATLAS_ROWS;
            // quad in shape space: cell mapped so glyph origin (pad, baseline) lands at (x, baseY)
            const qx = x - GLYPH_PAD * s, qy = baseY - BASELINE * s, qs = CELL * s;
            emit(OP.GLYPH, u0, v0, u1, v1, qx, qy, qs, s);
            if (!first) emit(OP.UNION); first = false;
          }
          x += adv;
        }
        if (first) emit(OP.NOTHING);
        break;
      }
      case "union": case "inter": case "sunion": case "sinter": {
        if (n.kids.length === 0) { emit(OP.NOTHING); break; }
        n.kids.forEach((kid, i) => {
          walk(kid);
          if (i > 0) {
            if (n.k === "union") emit(OP.UNION); else if (n.k === "inter") emit(OP.INTER);
            else if (n.k === "sunion") emit(OP.SUNION, n.s); else emit(OP.SINTER, n.s);
          }
        });
        break;
      }
      case "diff": walk(n.a); walk(n.b); emit(OP.DIFF); break;
      case "round": walk(n.s); emit(OP.ROUND, n.r); break;
      case "stroke": walk(n.s); emit(OP.STROKE, n.w / 2); break;
      case "colour": walk(n.s); emit(OP.COLOUR, ...n.c); break;
      case "opacity": walk(n.s); emit(OP.OPACITY, n.a); break;
      case "grad": walk(n.s); emit(OP.GRAD, n.c1[0], n.c1[1], n.c1[2], n.c2[0], n.c2[1], n.c2[2], n.x0, n.y0, n.x1, n.y1, n.c1[3]); break;
      case "shadow":
        // offset soft copy first, then the real shape composited over it
        emit(OP.PUSH_XF, n.dx, n.dy, 1, 0, 1); walk(n.s); emit(OP.POP_XF);
        emit(OP.SHADOW, Math.max(0.5, n.blur), n.a);
        walk(n.s); emit(OP.UNION);
        break;
      case "xform": emit(OP.PUSH_XF, n.tx, n.ty, Math.cos(n.rot), Math.sin(n.rot), n.sc || 1); walk(n.s); emit(OP.POP_XF); break;
    }
  };
  walk(root);
  emit(OP.END);
  return new Float32Array(out);
}
