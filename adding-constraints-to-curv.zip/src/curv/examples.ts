export interface Example { id: string; name: string; blurb: string; src: string }

export const EXAMPLES: Example[] = [
  {
    id: "split",
    name: "Responsive split",
    blurb: "Cassowary-style layout: resize the canvas and psolve re-solves the constraints every frame.",
    src: `// Two panes sharing the parent width.  Nothing here is positioned by
// hand: every x/y/w/h comes out of the \`solve\` block, which psolve
// (convex QP, active-set) solves in microseconds on each resize.
let
  pad = 20;
  L = solve {
    var left, right : box;

    left.x == pad;                 left.y == pad;
    left.right + 16 == right.x;    right.y == left.y;
    right.right == parent.width - pad;
    left.bottom == parent.height - pad;
    right.h == left.h;

    left.w == 2 * right.w;         // the classic AutoLayout ratio
    weak: right.w == 260;          // preferred width, yields under pressure
  };
in union [
  card L.left,
  card L.right,
  text "left.w == 2 * right.w" 16 >> colour fg >> at L.left,
  text (strcat ["left ", round L.left.w, " px"]) 13 >> colour muted
    >> translate (L.left.cx, L.left.cy + 28),
  text (strcat ["right ", round L.right.w, " px"]) 13 >> colour muted
    >> translate (L.right.cx, L.right.cy + 28),
  text "right" 16 >> colour fg >> at L.right,
]`,
  },
  {
    id: "dashboard",
    name: "Dashboard",
    blurb: "Sidebar, header and an equal-width card grid — all from one constraint system, with soft preferences.",
    src: `// A whole dashboard from one solve block.  Try dragging the canvas
// width: the sidebar shrinks between its bounds before the cards do.
let
  pad = 16; gap = 14; n = 6; cols = 3;
  L = solve {
    var side, head, main : box;
    var cards : box[n];

    // frame
    side.pos == (pad, pad);         side.bottom == parent.height - pad;
    head.y == pad;                  head.h == 56;
    head.x == side.right + gap;     head.right == parent.width - pad;
    main.x == head.x;               main.right == head.right;
    main.y == head.bottom + gap;    main.bottom == side.bottom;

    // sidebar prefers 200px but may compress
    weak: side.w == 200;   side.w >= 96;   side.w <= 220;

    // 3-column grid of equal cards inside main
    for (i in 0..n-1) {
      c = i % cols;  r = floor (i / cols);
      cards.[i].w == cards.[0].w;   cards.[i].h == cards.[0].h;
      cards.[i].x == main.x + c * (cards.[0].w + gap);
      cards.[i].y == main.y + r * (cards.[0].h + gap);
    }
    cards.[cols-1].right == main.right;
    cards.[n-1].bottom == main.bottom;
  };
  titles = ["Revenue", "Sessions", "Latency", "Errors", "Signups", "Churn"];
  values = ["$48.2k", "128k", "42 ms", "0.3%", "1,204", "1.9%"];
  ratios = [0.72, 0.55, 0.31, 0.12, 0.64, 0.22];
  colours = [accent, accent_2, success, danger, accent_3, warning];
  nav i = box (L.side.x + 12, L.side.y + 64 + i*40, L.side.w - 24, 32);
in union [
  card L.side,
  avatar (box (L.side.x + 12, L.side.y + 12, 36, 36)) "CV",
  for (i in 0..4)
    union [ frame_r 8 (nav i) >> colour (if i == 0 then surface_3 else surface),
            circle 8 >> colour (if i == 0 then accent else border)
              >> translate ((nav i).x + 14, (nav i).cy) ],
  panel L.head,
  text_left "Overview" 18 >> colour fg >> translate (L.head.x + 18, L.head.cy + 6),
  button (box (L.head.right - 116, L.head.y + 11, 104, 34)) "New report",
  for (i in 0..n-1)
    let b = cards.[i]; in union [
      card b,
      text_left titles.[i] 12 >> colour muted >> translate (b.x + 16, b.y + 26),
      text_left values.[i] 22 >> colour fg >> translate (b.x + 16, b.y + 56),
      progress (box (b.x + 16, b.bottom - 24, b.w - 32, 6)) ratios.[i] colours.[i],
    ]
] where cards = L.cards`,
  },
  {
    id: "buttons",
    name: "Intrinsic sizing",
    blurb: "Buttons measure their labels (text_width) and the solver distributes the leftover space.",
    src: `// Content-driven layout: each button must be at least as wide as its
// label + padding, all buttons share one width if possible (weak), and
// the row is centred in the parent.  Change a label and watch it re-flow.
let
  labels = ["Cancel", "Save draft", "Publish now", "Schedule for later"];
  n = count labels;  gap = 10;  h = 42;
  L = solve {
    var b : box[n];
    var row : box;
    row.h == h;   row.cy == parent.height / 2;
    row.cx == parent.width / 2;                 // centred row
    row.w <= parent.width - 32;
    for (i in 0..n-1) {
      b.[i].h == h;   b.[i].y == row.y;
      b.[i].w >= text_width labels.[i] 14 + 36; // intrinsic minimum
      weak: b.[i].w == b.[0].w;                 // equal widths when room allows
    }
    b.[0].x == row.x;
    for (i in 1..n-1) b.[i].x == b.[i-1].right + gap;
    b.[n-1].right == row.right;
    maximize row.w;                             // stretch (bounded above)
  };
in union [
  frame_r 14 (inset (-14) L.row) >> colour surface,
  ghost_button L.b.[0] labels.[0],
  ghost_button L.b.[1] labels.[1],
  button L.b.[2] labels.[2],
  button L.b.[3] labels.[3],
  text "b[i].w >= text_width label 14 + 36" 12 >> colour muted
    >> translate (parent.cx, L.row.bottom + 44),
]`,
  },
  {
    id: "tooltip",
    name: "Constrained tooltip",
    blurb: "Move the mouse: the tooltip wants to follow the cursor (weak) but must stay inside the canvas (required).",
    src: `// Soft goals vs. hard limits.  The tooltip *wants* to sit centred above
// the cursor, but it *must* stay 10px inside the parent.  psolve finds
// the least-squares compromise (this is an honest convex QP).
let
  title = "tip.cx == mouse.x  (weak)";
  L = solve {
    var tip, arrow : box;
    tip.w == text_width title 12 + 32;  tip.h == 54;   // sized by its label
    arrow.size == (14, 14);
    weak: tip.cx == mouse.x;
    weak: tip.bottom == mouse.y - 18;
    tip.x >= 10;  tip.right <= parent.width - 10;
    tip.y >= 10;  tip.bottom <= parent.height - 10;
    arrow.cx == tip.cx;  arrow.cy == tip.bottom;
    medium: arrow.cx == mouse.x;
  };
  label = strcat ["(", round mouse.x, ", ", round mouse.y, ")"];
in union [
  frame parent >> gradient (surface, ink) ((0, 0), (0, parent.height)),
  for (x in 0..parent.width by 40) line ((x, 0), (x, parent.height)) 1 >> colour surface_2,
  for (y in 0..parent.height by 40) line ((0, y), (parent.width, y)) 1 >> colour surface_2,
  circle 10 >> colour accent_2 >> translate mouse.pos,
  ring 26 2 >> colour accent_2 >> opacity 0.5 >> translate mouse.pos,
  union [
    square 14 >> rotate (pi/4) >> colour surface_3 >> at L.arrow,
    frame_r 12 L.tip >> colour surface_3,
  ] >> shadow (0, 6) 14,
  text title 12 >> colour fg >> translate (L.tip.cx, L.tip.y + 20),
  text label 12 >> colour muted >> translate (L.tip.cx, L.tip.y + 38),
]`,
  },
  {
    id: "chart",
    name: "Animated chart",
    blurb: "Bars re-solved every frame: equal spacing, bounded widths, heights from data driven by time.",
    src: `// Live data + layout solver at 60 fps.  Bar spacing/width is decided
// by psolve (LP/QP), the bar heights are plain Curv math on \`time\`.
let
  n = 12;  pad = 28;  gap_min = 6;
  data = [for (i in 0..n-1) 0.5 + 0.45 * sin (time*1.3 + i*0.7) * cos (time*0.4 + i)];
  L = solve {
    var plot : box;   var bars : box[n];   var gap;
    plot.pos == (pad, pad);  plot.right == parent.width - pad;
    plot.bottom == parent.height - pad - 24;
    gap >= gap_min;
    for (i in 0..n-1) {
      bars.[i].w == bars.[0].w;   bars.[i].bottom == plot.bottom;
      bars.[i].h == plot.h * data.[i];
      bars.[i].w <= 64;
    }
    bars.[0].x == plot.x;
    for (i in 1..n-1) bars.[i].x == bars.[i-1].right + gap;
    bars.[n-1].right == plot.right;
    weak: gap == 14;                       // preferred gap; width absorbs the rest
  };
in union [
  frame_r 18 (inset (-12) L.plot) >> colour surface,
  for (k in 0..4) line ((L.plot.x, L.plot.y + k*L.plot.h/4), (L.plot.right, L.plot.y + k*L.plot.h/4)) 1 >> colour border,
  for (i in 0..n-1)
    frame_r 6 L.bars.[i] >> gradient (accent_2, accent) ((0, L.plot.y), (0, L.plot.bottom)),
  for (i in 0..n-1)
    text (round (data.[i] * 100)) 11 >> colour muted
      >> translate (L.bars.[i].cx, L.bars.[i].y - 10),
  text (strcat ["gap = ", round L.gap, "px   bar = ", round L.bars.[0].w, "px"]) 12
    >> colour muted >> translate (parent.cx, parent.height - 16),
]`,
  },
  {
    id: "frep",
    name: "Pure F-Rep",
    blurb: "Classic Curv: signed-distance CSG (smooth union, difference, offset) with the solver placing the parts.",
    src: `// Curv's soul: shapes are distance fields, combined with CSG.  The
// solver only decides *where* the three blobs live so they always fit.
let
  L = solve {
    var a, b, c : box;
    a.size == (160, 160);  b.size == (120, 120);  c.size == (90, 90);
    a.cy == parent.cy;  b.cy == a.cy - 40;  c.cy == a.cy + 50;
    b.x == a.cx + 20;   c.x == b.cx + 10;
    a.cx + (c.right - a.x) / 2 == parent.cx + 40;   // group centred
    a.x >= 20;  c.right <= parent.width - 20;
  };
  blob = smooth_union 30 [
    circle a.w >> translate a.center,
    circle b.w >> translate b.center,
    rrect c.size 20 >> rotate (time*0.7) >> translate c.center,
  ] where {a = L.a; b = L.b; c = L.c};
  hole = circle 70 >> translate (L.a.cx - 30, L.a.cy + 10);
  body = difference [blob, hole >> offset (10 * sin time)];
in union [
  body >> gradient (accent, accent_3) ((L.a.x, 0), (L.c.right, 0)),
  body >> stroke 2 >> colour white >> opacity 0.35,
  hole >> stroke 1 >> colour accent_2 >> opacity 0.6,
  text "difference [smooth_union 30 [..], circle 70]" 12 >> colour muted
    >> translate (parent.cx, parent.height - 22),
]`,
  },
];
