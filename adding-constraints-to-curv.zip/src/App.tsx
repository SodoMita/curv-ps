import { useCallback, useEffect, useRef, useState } from "react";
import { Editor } from "./components/Editor";
import { SolverPanel } from "./components/SolverPanel";
import { Reference } from "./components/Reference";
import { EXAMPLES } from "./curv/examples";
import { Interp, type SolveTrace } from "./curv/interp";
import { CurvError } from "./curv/parser";
import { compileProgram, type SNode } from "./curv/shapes";
import { buildAtlas, type Atlas } from "./gpu/atlas";
import { createRenderer, type Renderer } from "./gpu/renderer";
import { loadPsolve } from "./psolve/psolve";
import { cn } from "./utils/cn";

const BG: [number, number, number] = [0x0e / 255, 0x13 / 255, 0x22 / 255];

export default function App() {
  const [exampleId, setExampleId] = useState(EXAMPLES[0].id);
  const [src, setSrc] = useState(EXAMPLES[0].src);
  const [error, setError] = useState<{ message: string; line?: number } | null>(null);
  const [traces, setTraces] = useState<SolveTrace[]>([]);
  const [evalMs, setEvalMs] = useState(0);
  const [fps, setFps] = useState(0);
  const [status, setStatus] = useState<"loading" | "ready" | "failed">("loading");
  const [rendererInfo, setRendererInfo] = useState<{ kind: string; info?: string } | null>(null);
  const [previewPct, setPreviewPct] = useState(100);
  const [showRef, setShowRef] = useState(false);
  const [debugBoxes, setDebugBoxes] = useState(false);

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const renderer = useRef<Renderer | null>(null);
  const atlas = useRef<Atlas | null>(null);
  const srcRef = useRef(src);
  const dirty = useRef(true);
  const dynamic = useRef<{ time: boolean; mouse: boolean }>({ time: false, mouse: false });
  const mouse = useRef({ x: -1000, y: -1000, down: false });
  const t0 = useRef(performance.now());
  const lastUi = useRef(0);
  const frames = useRef<{ n: number; t: number }>({ n: 0, t: performance.now() });
  const debugRef = useRef(false);

  useEffect(() => { srcRef.current = src; }, [src]);
  useEffect(() => { debugRef.current = debugBoxes; dirty.current = true; }, [debugBoxes]);

  // ---- boot: psolve wasm + glyph atlas + renderer
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        await loadPsolve();
        atlas.current = buildAtlas();
        if (!canvasRef.current || cancelled) return;
        const r = await createRenderer(canvasRef.current, atlas.current);
        if (cancelled) { r.destroy(); return; }
        renderer.current = r;
        setRendererInfo({ kind: r.kind, info: r.adapterInfo });
        setStatus("ready");
        dirty.current = true;
      } catch (e) {
        console.error(e); setStatus("failed");
        setError({ message: "Failed to initialise: " + (e as Error).message });
      }
    })();
    return () => { cancelled = true; renderer.current?.destroy(); };
  }, []);

  // ---- one evaluation + render
  const evaluate = useCallback((force = false) => {
    const cv = canvasRef.current, r = renderer.current, at = atlas.current;
    if (!cv || !r || !at) return;
    const now = performance.now();
    const inputs = { width: cv.clientWidth, height: cv.clientHeight, time: (now - t0.current) / 1000, mouse: { ...mouse.current } };
    const it = new Interp(at, inputs);
    let ok = true;
    try {
      const res = it.run(srcRef.current);
      let node = res.shape ?? { k: "nothing" as const };
      if (debugRef.current) {
        const kids: SNode[] = [node];
        for (const t of res.traces) for (const b of t.boxes)
          kids.push({ k: "xform", tx: b.x + b.w / 2, ty: b.y + b.h / 2, rot: 0, sc: 1, s: { k: "colour", c: [0.96, 0.45, 0.71, 0.9], s: { k: "stroke", w: 1, s: { k: "rect", w: b.w, h: b.h, r: 0 } } } });
        node = { k: "union", kids };
      }
      const prog = compileProgram(node, at);
      dynamic.current = { time: res.usesTime, mouse: res.usesMouse };
      r.render(prog, BG, inputs.time);
      const ms = performance.now() - now;
      const animating = res.usesTime;
      if (force || !animating || now - lastUi.current > 250) {
        lastUi.current = now;
        setTraces(res.traces); setEvalMs(ms); setError(null);
      }
    } catch (e) {
      ok = false;
      const err = e as CurvError;
      setError({ message: err.message, line: err instanceof CurvError ? err.line : undefined });
      setTraces(it.traces);
      dynamic.current = { time: false, mouse: false };
    }
    return ok;
  }, []);

  // ---- frame loop
  useEffect(() => {
    let raf = 0;
    const tick = () => {
      raf = requestAnimationFrame(tick);
      if (status !== "ready") return;
      if (dirty.current || dynamic.current.time) {
        const wasDirty = dirty.current; dirty.current = false;
        evaluate(wasDirty);
        const f = frames.current; f.n++;
        const now = performance.now();
        if (now - f.t > 1000) { setFps(dynamic.current.time ? (f.n * 1000) / (now - f.t) : 0); f.n = 0; f.t = now; }
      }
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [status, evaluate]);

  // ---- source changes (debounced), resize, mouse
  useEffect(() => { const h = setTimeout(() => { dirty.current = true; }, 120); return () => clearTimeout(h); }, [src]);
  useEffect(() => {
    const cv = canvasRef.current; if (!cv) return;
    const ro = new ResizeObserver(() => { renderer.current?.resize(); dirty.current = true; });
    ro.observe(cv); return () => ro.disconnect();
  }, []);
  const onMouse = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    mouse.current = { x: e.clientX - rect.left, y: e.clientY - rect.top, down: e.buttons > 0 };
    if (dynamic.current.mouse) dirty.current = true;
  };

  const loadExample = (id: string) => {
    const ex = EXAMPLES.find((e) => e.id === id)!; setExampleId(id); setSrc(ex.src); t0.current = performance.now(); dirty.current = true;
  };
  const example = EXAMPLES.find((e) => e.id === exampleId)!;

  return (
    <div className="flex h-full min-h-0 flex-col">
      {/* header */}
      <header className="flex h-14 shrink-0 items-center gap-4 border-b border-line bg-surface/70 px-5 backdrop-blur">
        <div className="flex items-center gap-2.5">
          <div className="grid h-7 w-7 place-items-center rounded-md bg-gradient-to-br from-accent to-accent-2 font-mono text-[13px] font-bold text-white shadow-lg shadow-accent/30">C⁺</div>
          <div className="leading-tight">
            <div className="text-[15px] font-semibold tracking-tight">Curv<sup className="text-accent-2">+solve</sup></div>
            <div className="text-[10.5px] text-muted">F-Rep UI · constraint layout · rendered as signed distance fields</div>
          </div>
        </div>
        <div className="ml-auto flex items-center gap-2 text-[11px]">
          <Badge dot={status === "ready" ? "ok" : status === "failed" ? "bad" : "wait"}>
            psolve wasm · {status === "ready" ? "LP simplex + QP active-set" : status}
          </Badge>
          <Badge dot={rendererInfo?.kind === "webgpu" ? "ok" : rendererInfo ? "warn" : "wait"}>
            {rendererInfo ? (rendererInfo.kind === "webgpu" ? rendererInfo.info ?? "WebGPU" : "CPU fallback (WebGPU unavailable)") : "renderer…"}
          </Badge>
          <button onClick={() => setShowRef((s) => !s)} className={cn("rounded-md border border-line px-2.5 py-1 hover:bg-surface-2", showRef && "bg-surface-3 text-white")}>Reference</button>
        </div>
      </header>

      {/* body */}
      <div className="grid min-h-0 flex-1 grid-cols-1 lg:grid-cols-[minmax(380px,42%)_1fr]">
        {/* left: examples + editor */}
        <section className="flex min-h-0 flex-col border-r border-line">
          <div className="flex gap-1.5 overflow-x-auto border-b border-line px-3 py-2">
            {EXAMPLES.map((ex) => (
              <button key={ex.id} onClick={() => loadExample(ex.id)}
                className={cn("shrink-0 rounded-md px-2.5 py-1 text-[11.5px] transition", ex.id === exampleId ? "bg-accent text-white shadow-md shadow-accent/30" : "text-muted hover:bg-surface-2 hover:text-fg")}>
                {ex.name}
              </button>
            ))}
          </div>
          <div className="border-b border-line px-4 py-2 text-[11.5px] text-muted">{example.blurb}</div>
          <div className="min-h-0 flex-1 bg-ink">
            <Editor value={src} onChange={setSrc} errorLine={error?.line} />
          </div>
          <div className={cn("shrink-0 border-t border-line px-4 py-2 font-mono text-[11.5px]", error ? "bg-rose-500/10 text-rose-300" : "text-muted")}>
            {error ? <><span className="font-semibold">error</span>{error.line ? ` (line ${error.line})` : ""}: {error.message}</> : <>✓ program evaluates · {src.split("\n").length} lines · edits re-solve live</>}
          </div>
        </section>

        {/* right: preview + solver */}
        <section className="grid min-h-0 grid-rows-[minmax(0,1fr)_minmax(180px,34%)]">
          <div className="flex min-h-0 flex-col">
            <div className="flex items-center gap-3 border-b border-line px-4 py-2 text-[11px] text-muted">
              <span className="font-semibold uppercase tracking-[0.14em]">Preview</span>
              <span className="hidden sm:inline">canvas = <span className="font-mono text-fg/80">parent</span></span>
              <label className="ml-auto flex items-center gap-2">
                <span>width</span>
                <input type="range" min={35} max={100} value={previewPct} onChange={(e) => setPreviewPct(+e.target.value)} className="w-32 accent-[#7c5cff]" />
                <span className="w-9 font-mono">{previewPct}%</span>
              </label>
              <label className="flex items-center gap-1.5"><input type="checkbox" checked={debugBoxes} onChange={(e) => setDebugBoxes(e.target.checked)} className="accent-[#7c5cff]" />outline solved boxes</label>
            </div>
            <div className="relative min-h-0 flex-1 overflow-hidden bg-[#0e1322] p-4"
              style={{ backgroundImage: "radial-gradient(circle at 1px 1px, #1d2537 1px, transparent 0)", backgroundSize: "20px 20px" }}>
              <div className="mx-auto h-full transition-[width] duration-150" style={{ width: `${previewPct}%` }}>
                <canvas ref={canvasRef} onMouseMove={onMouse} onMouseDown={onMouse} onMouseUp={onMouse} onMouseLeave={() => { mouse.current = { x: -1000, y: -1000, down: false }; if (dynamic.current.mouse) dirty.current = true; }}
                  className="block h-full w-full rounded-xl border border-line shadow-2xl shadow-black/50" />
              </div>
              {status !== "ready" && (
                <div className="absolute inset-0 grid place-items-center bg-ink/70 text-sm text-muted">
                  {status === "failed" ? "Initialisation failed — see error" : "Loading psolve.wasm & building glyph atlas…"}
                </div>
              )}
            </div>
          </div>
          <div className="min-h-0 border-t border-line bg-ink">
            <SolverPanel traces={traces} evalMs={evalMs} fps={fps} />
          </div>
        </section>
      </div>

      {showRef && (
        <div className="max-h-[46vh] shrink-0 overflow-auto border-t border-line bg-surface/60 px-6 py-5">
          <div className="mb-4 flex flex-wrap items-start gap-6">
            <div className="max-w-3xl text-[12px] leading-relaxed text-muted">
              <span className="text-fg">How it works.</span> A <span className="font-mono text-accent-2">solve</span> block is an isolated, impure meta-layer: it collects linear
              constraints over unknowns, presolves hard equalities by Gaussian elimination, and hands the remaining convex problem to{" "}
              <a className="text-accent-2 underline decoration-dotted" href="https://github.com/SodoMita/psolve/tree/arena/cp-engine-correctness" target="_blank" rel="noreferrer">psolve</a>{" "}
              (unmodified C sources of the <span className="font-mono">arena/cp-engine-correctness</span> branch compiled to wasm32: revised simplex for pure LPs, active-set QP
              for soft constraints / quadratic objectives — soft constraints become squared error terms, Cassowary-style). The solved numbers feed pure Curv shape functions;
              the shape tree compiles to a postfix SDF program executed per pixel in a WebGPU fragment shader (Canvas2D fallback runs the same program on the CPU). Text is
              an SDF glyph atlas, so labels are shapes too and <span className="font-mono">text_width</span> can appear in constraints.
            </div>
          </div>
          <Reference />
        </div>
      )}
    </div>
  );
}

function Badge({ children, dot }: { children: React.ReactNode; dot: "ok" | "bad" | "wait" | "warn" }) {
  return (
    <span className="flex items-center gap-1.5 rounded-md border border-line bg-surface px-2.5 py-1 font-mono text-[10.5px] text-muted">
      <span className={cn("h-1.5 w-1.5 rounded-full", dot === "ok" && "bg-emerald-400", dot === "bad" && "bg-rose-400", dot === "warn" && "bg-amber-400", dot === "wait" && "animate-pulse bg-slate-400")} />
      {children}
    </span>
  );
}
