const sections: { title: string; rows: [string, string][] }[] = [
  {
    title: "solve { … }  (the extension)",
    rows: [
      ["var a, b;", "scalar unknowns"],
      ["var p : point;  var b : box;", "point {x,y}; box {x,y,w,h} + derived right, bottom, cx, cy, center, size, pos"],
      ["var cards : box[n];", "list of n unknown boxes (cards.[i])"],
      ["a.right + 10 == b.x;", "required linear constraint (==, <=, >=; chains like 0 <= x <= w)"],
      ["weak: b.w == 200;", "soft constraint: weak | medium | strong, optional weight: weak 3: …"],
      ["minimize (a.w - 1.618*a.h)^2;", "linear or convex-quadratic objective (also maximize)"],
      ["for (i in 0..n-1) { … }", "loops / if (c) { … } generate constraints; name = expr; binds locals"],
      ["L = solve { … };  L.a.w", "returns a record of solved values (+ L.solver.status / time_ms / engine)"],
    ],
  },
  {
    title: "Shapes (UI px, origin top-left)",
    rows: [
      ["circle d · rect (w,h) · rrect (w,h) r · ellipse (w,h)", "centred primitives"],
      ["line (p1,p2) th · half_plane n · nothing", ""],
      ["text \"hi\" 14 · text_left \"hi\" 14 · text_width \"hi\" 14", "SDF glyphs; text_width is a number you can constrain on"],
      ["frame b · frame_r r b · at b shape · inset d b · box (x,y,w,h)", "box helpers"],
      ["union [..] · intersection [..] · difference [a,b]", "CSG; union composes colours painter-style"],
      ["smooth_union k [..] · offset r · stroke w", "F-Rep operators on the distance field"],
      ["colour c · opacity a · gradient (c1,c2) (p0,p1) · shadow (dx,dy) blur", "appearance (colours: \"#hex\", (r,g,b), white, accent, …)"],
      ["translate (x,y) · rotate a · scale k · shape >> op", "transforms and Curv's pipe"],
      ["card b · panel b · button b \"label\" · avatar b \"AB\" · progress b t c · toggle b on", "prelude components written in Curv"],
    ],
  },
  {
    title: "Core Curv",
    rows: [
      ["let a = 1; f x = x*2; in …  /  expr where (…)", "definitions"],
      ["x -> x+1 · (a,b) -> a*b · f a b (curried)", "functions"],
      ["[for (i in 0..9) if (i%2==0) i*i] · 1..10 by 2", "comprehensions & ranges"],
      ["{a: 1, b: 2} · r.a · list.[i] · count · sum · map · strcat", "records, lists"],
      ["parent.width/height · time · mouse.x/y/pos", "live inputs: re-evaluated on resize / every frame / on move"],
    ],
  },
];

export function Reference() {
  return (
    <div className="grid gap-6 lg:grid-cols-3">
      {sections.map((s) => (
        <div key={s.title}>
          <h4 className="mb-2 text-[11px] font-semibold uppercase tracking-[0.14em] text-muted">{s.title}</h4>
          <dl className="space-y-1.5">
            {s.rows.map(([k, v]) => (
              <div key={k} className="rounded-md border border-line/60 bg-surface/50 px-3 py-1.5">
                <dt className="font-mono text-[11.5px] text-accent-2">{k}</dt>
                {v && <dd className="text-[11.5px] text-muted">{v}</dd>}
              </div>
            ))}
          </dl>
        </div>
      ))}
    </div>
  );
}
