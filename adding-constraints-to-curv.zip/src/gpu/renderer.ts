/// <reference types="@webgpu/types" />
import { SHADER } from "./shader";
import { ATLAS_W, ATLAS_H, SPREAD, type Atlas } from "./atlas";
import { INSTR_FLOATS } from "../curv/shapes";
import { renderCPU } from "./cpu";

export interface Renderer {
  kind: "webgpu" | "cpu";
  adapterInfo?: string;
  render(program: Float32Array, bg: [number, number, number], time: number): void;
  resize(): void;
  destroy(): void;
}

const MAX_INSTR = 6000;

export async function createRenderer(canvas: HTMLCanvasElement, atlas: Atlas): Promise<Renderer> {
  try {
    const r = await createWebGPU(canvas, atlas);
    if (r) return r;
  } catch (e) { console.warn("WebGPU init failed, using CPU fallback", e); }
  return createCPU(canvas, atlas);
}

async function createWebGPU(canvas: HTMLCanvasElement, atlas: Atlas): Promise<Renderer | null> {
  if (!("gpu" in navigator) || !navigator.gpu) return null;
  const adapter = await navigator.gpu.requestAdapter({ powerPreference: "high-performance" });
  if (!adapter) return null;
  const device = await adapter.requestDevice();
  const ctx = canvas.getContext("webgpu");
  if (!ctx) return null;
  const format = navigator.gpu.getPreferredCanvasFormat();
  ctx.configure({ device, format, alphaMode: "opaque" });

  const module = device.createShaderModule({ code: SHADER });
  const pipeline = device.createRenderPipeline({
    layout: "auto",
    vertex: { module, entryPoint: "vs" },
    fragment: { module, entryPoint: "fs", targets: [{ format }] },
    primitive: { topology: "triangle-list" },
  });
  const uniform = device.createBuffer({ size: 48, usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST });
  const progBuf = device.createBuffer({ size: MAX_INSTR * INSTR_FLOATS * 4, usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_DST });
  const tex = device.createTexture({ size: [ATLAS_W, ATLAS_H], format: "r8unorm", usage: GPUTextureUsage.TEXTURE_BINDING | GPUTextureUsage.COPY_DST });
  device.queue.writeTexture({ texture: tex }, atlas.data, { bytesPerRow: ATLAS_W }, [ATLAS_W, ATLAS_H]);
  const sampler = device.createSampler({ magFilter: "linear", minFilter: "linear" });
  const bind = device.createBindGroup({
    layout: pipeline.getBindGroupLayout(0),
    entries: [
      { binding: 0, resource: { buffer: uniform } },
      { binding: 1, resource: { buffer: progBuf } },
      { binding: 2, resource: tex.createView() },
      { binding: 3, resource: sampler },
    ],
  });
  let info = "WebGPU";
  try {
    const ai = (adapter as GPUAdapter & { info?: GPUAdapterInfo }).info;
    if (ai && (ai.description || ai.vendor)) info = `WebGPU · ${ai.description || ai.vendor}${ai.architecture ? " (" + ai.architecture + ")" : ""}`;
  } catch { /* ignore */ }

  const resize = () => {
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    const w = Math.max(1, Math.floor(canvas.clientWidth * dpr)), h = Math.max(1, Math.floor(canvas.clientHeight * dpr));
    if (canvas.width !== w || canvas.height !== h) { canvas.width = w; canvas.height = h; }
  };
  resize();
  const ubuf = new Float32Array(12);
  return {
    kind: "webgpu", adapterInfo: info, resize,
    render(program, bg, time) {
      resize();
      const dpr = canvas.width / Math.max(1, canvas.clientWidth);
      const count = Math.min(MAX_INSTR, program.length / INSTR_FLOATS);
      ubuf.set([canvas.clientWidth, canvas.clientHeight, time, count, bg[0], bg[1], bg[2], 1, ATLAS_W, ATLAS_H, SPREAD, dpr]);
      device.queue.writeBuffer(uniform, 0, ubuf);
      device.queue.writeBuffer(progBuf, 0, program.buffer, program.byteOffset, count * INSTR_FLOATS * 4);
      const enc = device.createCommandEncoder();
      const pass = enc.beginRenderPass({ colorAttachments: [{ view: ctx.getCurrentTexture().createView(), loadOp: "clear", storeOp: "store", clearValue: { r: bg[0], g: bg[1], b: bg[2], a: 1 } }] });
      pass.setPipeline(pipeline); pass.setBindGroup(0, bind); pass.draw(3); pass.end();
      device.queue.submit([enc.finish()]);
    },
    destroy() { try { device.destroy(); } catch { /* ignore */ } },
  };
}

function createCPU(canvas: HTMLCanvasElement, atlas: Atlas): Renderer {
  const ctx2d = canvas.getContext("2d")!;
  const resize = () => {
    const w = Math.max(1, Math.floor(canvas.clientWidth)), h = Math.max(1, Math.floor(canvas.clientHeight));
    if (canvas.width !== w || canvas.height !== h) { canvas.width = w; canvas.height = h; }
  };
  resize();
  return {
    kind: "cpu", resize,
    render(program, bg) { resize(); renderCPU(ctx2d, canvas.width, canvas.height, program, bg, atlas); },
    destroy() { /* nothing */ },
  };
}
