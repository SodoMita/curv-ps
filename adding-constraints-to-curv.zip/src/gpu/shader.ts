// WGSL: per-pixel stack machine that evaluates the compiled F-Rep program.
export const SHADER = /* wgsl */ `
struct U {
  res: vec2f, time: f32, count: f32,
  bg: vec4f,
  atlas: vec4f,  // atlas w, h, spread, dpr
};
@group(0) @binding(0) var<uniform> u: U;
@group(0) @binding(1) var<storage, read> prog: array<vec4f>;
@group(0) @binding(2) var atlasTex: texture_2d<f32>;
@group(0) @binding(3) var atlasSamp: sampler;

@vertex fn vs(@builtin(vertex_index) i: u32) -> @builtin(position) vec4f {
  var p = array<vec2f, 3>(vec2f(-1.0, -1.0), vec2f(3.0, -1.0), vec2f(-1.0, 3.0));
  return vec4f(p[i], 0.0, 1.0);
}

fn sdBox(p: vec2f, b: vec2f, r: f32) -> f32 {
  let q = abs(p) - b + vec2f(r);
  return length(max(q, vec2f(0.0))) + min(max(q.x, q.y), 0.0) - r;
}
fn sdSeg(p: vec2f, a: vec2f, b: vec2f) -> f32 {
  let pa = p - a; let ba = b - a;
  let h = clamp(dot(pa, ba) / max(dot(ba, ba), 1e-6), 0.0, 1.0);
  return length(pa - ba * h);
}
fn sdEllipse(p: vec2f, ab: vec2f) -> f32 {
  let k0 = length(p / ab); let k1 = length(p / (ab * ab));
  return k0 * (k0 - 1.0) / max(k1, 1e-6);
}
fn cov(d: f32) -> f32 { return clamp(0.5 - d, 0.0, 1.0); }
fn smin(a: f32, b: f32, k: f32) -> f32 {
  let h = clamp(0.5 + 0.5 * (b - a) / max(k, 1e-4), 0.0, 1.0);
  return mix(b, a, h) - k * h * (1.0 - h);
}

const MAXS: i32 = 24;
const MAXX: i32 = 12;

@fragment fn fs(@builtin(position) fc: vec4f) -> @location(0) vec4f {
  let dpr = u.atlas.w;
  var p = fc.xy / dpr;                 // CSS-pixel UI coordinates, origin top-left
  var sd: array<f32, 24>;
  var sc: array<vec4f, 24>;            // rgb + opacity (coverage excluded)
  var sp: i32 = 0;
  var xp: array<vec2f, 12>;
  var xs: array<f32, 12>;
  var xsp: i32 = 0;
  var scl: f32 = 1.0;
  let n = i32(u.count);
  for (var i: i32 = 0; i < n; i++) {
    let a = prog[i * 3]; let b = prog[i * 3 + 1]; let c = prog[i * 3 + 2];
    let op = i32(a.x);
    if (op == 0) { break; }
    if (op < 10) {          // ---- primitives push
      var d: f32 = 1e9;
      var col = vec4f(1.0, 1.0, 1.0, 1.0);
      if (op == 1) { d = length(p) - a.y; }
      else if (op == 2) { d = sdBox(p, vec2f(a.y, a.z), a.w); }
      else if (op == 3) { d = sdSeg(p, vec2f(a.y, a.z), vec2f(a.w, b.x)) - b.y; }
      else if (op == 4) { d = sdEllipse(p, vec2f(a.y, a.z)); }
      else if (op == 7) { d = dot(p, normalize(vec2f(a.y, a.z))); }
      else if (op == 6) {   // glyph: uv rect a.yzw,b.x ; quad origin b.yz ; quad size b.w ; scale c.x
        let q = (p - vec2f(b.y, b.z)) / max(b.w, 1e-6);
        let uv = vec2f(mix(a.y, a.w, clamp(q.x, 0.0, 1.0)), mix(a.z, b.x, clamp(q.y, 0.0, 1.0)));
        let t = textureSampleLevel(atlasTex, atlasSamp, uv, 0.0).r;
        let dg = (0.5 - t) * 2.0 * u.atlas.z * c.x;   // back to pixels in shape space
        let bd = sdBox(p - vec2f(b.y, b.z) - vec2f(b.w * 0.5), vec2f(b.w * 0.5), 0.0);
        d = max(dg, bd);
      }
      if (sp < MAXS) { sd[sp] = d; sc[sp] = col; sp++; }
    } else if (op < 20) {   // ---- binary combinators (b = top, a = below)
      if (sp >= 2) {
        let db = sd[sp - 1]; let cb = sc[sp - 1]; let da = sd[sp - 2]; let ca = sc[sp - 2];
        sp -= 1;
        if (op == 10) {       // union with painter's-order colour ("over")
          let d = min(da, db);
          let wa = cov(da) * ca.a; let wb = cov(db) * cb.a;
          let at = wb + wa * (1.0 - wb);
          let rgb = select((cb.rgb * wb + ca.rgb * wa * (1.0 - wb)) / max(at, 1e-5), ca.rgb, at < 1e-5);
          sd[sp - 1] = d; sc[sp - 1] = vec4f(rgb, min(1.0, at / max(cov(d), 1e-5)));
        } else if (op == 11) { sd[sp - 1] = max(da, db); sc[sp - 1] = select(ca, cb, db > da); }
        else if (op == 12) { sd[sp - 1] = max(da, -db); sc[sp - 1] = ca; }
        else if (op == 13) {
          let d = smin(da, db, a.y);
          let h = clamp(0.5 + 0.5 * (da - db) / max(a.y, 1e-4), 0.0, 1.0);
          sd[sp - 1] = d; sc[sp - 1] = mix(ca, cb, h);
        } else if (op == 14) {
          let d = -smin(-da, -db, a.y);
          sd[sp - 1] = d; sc[sp - 1] = select(ca, cb, db > da);
        }
      }
    } else if (op < 30) {   // ---- unary modifiers on top of stack
      if (sp >= 1) {
        if (op == 20) { sd[sp - 1] = sd[sp - 1] - a.y; }
        else if (op == 21) { sd[sp - 1] = abs(sd[sp - 1]) - a.y; }
        else if (op == 22) { sc[sp - 1] = vec4f(a.y, a.z, a.w, b.x); }
        else if (op == 23) {
          let p0 = vec2f(b.w, c.x); let p1 = vec2f(c.y, c.z); let dv = p1 - p0;
          let t = clamp(dot(p - p0, dv) / max(dot(dv, dv), 1e-6), 0.0, 1.0);
          sc[sp - 1] = vec4f(mix(vec3f(a.y, a.z, a.w), vec3f(b.x, b.y, b.z), t), c.w);
        }
        else if (op == 24) { sc[sp - 1] = vec4f(sc[sp - 1].rgb, sc[sp - 1].a * a.y); }
        else if (op == 25) {  // shadowify: turn top into a soft dark blob (blur a.y, alpha a.z)
          let d = sd[sp - 1];
          let s = 1.0 - smoothstep(-a.y, a.y, d);
          sd[sp - 1] = d - a.y - 0.5;
          sc[sp - 1] = vec4f(0.0, 0.0, 0.0, a.z * s);
        }
      }
    } else if (op == 30) {  // push transform: p' = R^-1 (p - t) / s
      if (xsp < MAXX) {
        xp[xsp] = p; xs[xsp] = scl; xsp++;
        let q = p - vec2f(a.y, a.z);
        let cs = a.w; let sn = b.x; let s = max(b.y, 1e-6);
        p = vec2f(cs * q.x + sn * q.y, -sn * q.x + cs * q.y) / s;
        scl = scl * s;
      }
    } else if (op == 31) {  // pop transform: rescale distance of top
      if (xsp > 0) {
        xsp--; let s = scl / max(xs[xsp], 1e-9);
        p = xp[xsp]; scl = xs[xsp];
        if (sp >= 1) { sd[sp - 1] = sd[sp - 1] * s; }
      }
    }
  }
  var outc = u.bg.rgb;
  if (sp >= 1) {
    let d = sd[sp - 1]; let col = sc[sp - 1];
    let aa = cov(d) * col.a;
    outc = mix(outc, col.rgb, aa);
  }
  return vec4f(outc, 1.0);
}
`;
