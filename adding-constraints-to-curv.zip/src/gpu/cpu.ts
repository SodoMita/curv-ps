// Canvas2D fallback: evaluates the same postfix SDF program per pixel on the
// CPU (at reduced resolution) for browsers without WebGPU.
import { INSTR_FLOATS, OP } from "../curv/shapes";
import { ATLAS_W, ATLAS_H, SPREAD, type Atlas } from "./atlas";

const clamp01 = (x: number) => (x < 0 ? 0 : x > 1 ? 1 : x);
const cov = (d: number) => clamp01(0.5 - d);
const smooth = (e0: number, e1: number, x: number) => { const t = clamp01((x - e0) / (e1 - e0)); return t * t * (3 - 2 * t); };
function sdBox(px: number, py: number, bx: number, by: number, r: number) {
  const qx = Math.abs(px) - bx + r, qy = Math.abs(py) - by + r;
  return Math.hypot(Math.max(qx, 0), Math.max(qy, 0)) + Math.min(Math.max(qx, qy), 0) - r;
}
function smin(a: number, b: number, k: number) { const h = clamp01(0.5 + 0.5 * (b - a) / Math.max(k, 1e-4)); return (b + (a - b) * h) - k * h * (1 - h); }

export function renderCPU(ctx: CanvasRenderingContext2D, W: number, H: number, prog: Float32Array, bg: [number, number, number], atlas: Atlas) {
  const scale = W * H > 250000 ? 0.5 : 1;
  const w = Math.max(1, Math.floor(W * scale)), h = Math.max(1, Math.floor(H * scale));
  const img = ctx.createImageData(w, h); const px = img.data;
  const n = prog.length / INSTR_FLOATS;
  const sd = new Float64Array(24), sr = new Float64Array(24), sg = new Float64Array(24), sb = new Float64Array(24), sa = new Float64Array(24);
  const xpx = new Float64Array(12), xpy = new Float64Array(12), xsc = new Float64Array(12);
  const sampleAtlas = (u: number, v: number) => {
    const x = Math.min(ATLAS_W - 1, Math.max(0, Math.round(u * ATLAS_W - 0.5))), y = Math.min(ATLAS_H - 1, Math.max(0, Math.round(v * ATLAS_H - 0.5)));
    return atlas.data[y * ATLAS_W + x] / 255;
  };
  for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) {
    let p0x = (i + 0.5) / scale, p0y = (j + 0.5) / scale, ppx = p0x, ppy = p0y;
    let sp = 0, xsp = 0, scl = 1;
    for (let k = 0; k < n; k++) {
      const o = k * INSTR_FLOATS; const op = prog[o];
      if (op === OP.END) break;
      if (op < 10) {
        let d = 1e9;
        if (op === OP.CIRCLE) d = Math.hypot(ppx, ppy) - prog[o + 1];
        else if (op === OP.RECT) d = sdBox(ppx, ppy, prog[o + 1], prog[o + 2], prog[o + 3]);
        else if (op === OP.SEG) { const ax = prog[o + 1], ay = prog[o + 2], bx = prog[o + 3], by = prog[o + 4]; const pax = ppx - ax, pay = ppy - ay, bax = bx - ax, bay = by - ay; const t = clamp01((pax * bax + pay * bay) / Math.max(bax * bax + bay * bay, 1e-6)); d = Math.hypot(pax - bax * t, pay - bay * t) - prog[o + 5]; }
        else if (op === OP.ELLIPSE) { const a = prog[o + 1], b = prog[o + 2]; const k0 = Math.hypot(ppx / a, ppy / b), k1 = Math.hypot(ppx / (a * a), ppy / (b * b)); d = k0 * (k0 - 1) / Math.max(k1, 1e-6); }
        else if (op === OP.HALF) { const l = Math.hypot(prog[o + 1], prog[o + 2]) || 1; d = (ppx * prog[o + 1] + ppy * prog[o + 2]) / l; }
        else if (op === OP.GLYPH) {
          const u0 = prog[o + 1], v0 = prog[o + 2], u1 = prog[o + 3], v1 = prog[o + 4], qx = prog[o + 5], qy = prog[o + 6], qs = prog[o + 7], gs = prog[o + 8];
          const tx = clamp01((ppx - qx) / qs), ty = clamp01((ppy - qy) / qs);
          const t = sampleAtlas(u0 + (u1 - u0) * tx, v0 + (v1 - v0) * ty);
          const dg = (0.5 - t) * 2 * SPREAD * gs; const bd = sdBox(ppx - qx - qs / 2, ppy - qy - qs / 2, qs / 2, qs / 2, 0);
          d = Math.max(dg, bd);
        }
        if (sp < 24) { sd[sp] = d; sr[sp] = 1; sg[sp] = 1; sb[sp] = 1; sa[sp] = 1; sp++; }
      } else if (op < 20) {
        if (sp >= 2) {
          const B = sp - 1, A = sp - 2; const da = sd[A], db = sd[B]; sp--;
          if (op === OP.UNION) {
            const d = Math.min(da, db); const wa = cov(da) * sa[A], wb = cov(db) * sa[B]; const at = wb + wa * (1 - wb);
            if (at > 1e-5) { sr[A] = (sr[B] * wb + sr[A] * wa * (1 - wb)) / at; sg[A] = (sg[B] * wb + sg[A] * wa * (1 - wb)) / at; sb[A] = (sb[B] * wb + sb[A] * wa * (1 - wb)) / at; }
            sd[A] = d; sa[A] = Math.min(1, at / Math.max(cov(d), 1e-5));
          } else if (op === OP.INTER) { sd[A] = Math.max(da, db); if (db > da) { sr[A] = sr[B]; sg[A] = sg[B]; sb[A] = sb[B]; sa[A] = sa[B]; } }
          else if (op === OP.DIFF) { sd[A] = Math.max(da, -db); }
          else if (op === OP.SUNION) { const kk = prog[o + 1]; const hh = clamp01(0.5 + 0.5 * (da - db) / Math.max(kk, 1e-4)); sd[A] = smin(da, db, kk); sr[A] += (sr[B] - sr[A]) * hh; sg[A] += (sg[B] - sg[A]) * hh; sb[A] += (sb[B] - sb[A]) * hh; sa[A] += (sa[B] - sa[A]) * hh; }
          else if (op === OP.SINTER) { sd[A] = -smin(-da, -db, prog[o + 1]); if (db > da) { sr[A] = sr[B]; sg[A] = sg[B]; sb[A] = sb[B]; sa[A] = sa[B]; } }
        }
      } else if (op < 30) {
        if (sp >= 1) {
          const T = sp - 1;
          if (op === OP.ROUND) sd[T] -= prog[o + 1];
          else if (op === OP.STROKE) sd[T] = Math.abs(sd[T]) - prog[o + 1];
          else if (op === OP.COLOUR) { sr[T] = prog[o + 1]; sg[T] = prog[o + 2]; sb[T] = prog[o + 3]; sa[T] = prog[o + 4]; }
          else if (op === OP.GRAD) { const x0 = prog[o + 7], y0 = prog[o + 8], dx = prog[o + 9] - x0, dy = prog[o + 10] - y0; const t = clamp01(((ppx - x0) * dx + (ppy - y0) * dy) / Math.max(dx * dx + dy * dy, 1e-6)); sr[T] = prog[o + 1] + (prog[o + 4] - prog[o + 1]) * t; sg[T] = prog[o + 2] + (prog[o + 5] - prog[o + 2]) * t; sb[T] = prog[o + 3] + (prog[o + 6] - prog[o + 3]) * t; sa[T] = prog[o + 11]; }
          else if (op === OP.OPACITY) sa[T] *= prog[o + 1];
          else if (op === OP.SHADOW) { const d = sd[T], bl = prog[o + 1]; const s = 1 - smooth(-bl, bl, d); sd[T] = d - bl - 0.5; sr[T] = 0; sg[T] = 0; sb[T] = 0; sa[T] = prog[o + 2] * s; }
        }
      } else if (op === OP.PUSH_XF) {
        if (xsp < 12) {
          xpx[xsp] = ppx; xpy[xsp] = ppy; xsc[xsp] = scl; xsp++;
          const qx = ppx - prog[o + 1], qy = ppy - prog[o + 2], cs = prog[o + 3], sn = prog[o + 4], s = Math.max(prog[o + 5], 1e-6);
          ppx = (cs * qx + sn * qy) / s; ppy = (-sn * qx + cs * qy) / s; scl *= s;
        }
      } else if (op === OP.POP_XF) {
        if (xsp > 0) { xsp--; const s = scl / Math.max(xsc[xsp], 1e-9); ppx = xpx[xsp]; ppy = xpy[xsp]; scl = xsc[xsp]; if (sp >= 1) sd[sp - 1] *= s; }
      }
    }
    let r = bg[0], g = bg[1], b = bg[2];
    if (sp >= 1) { const T = sp - 1; const aa = cov(sd[T]) * sa[T]; r += (sr[T] - r) * aa; g += (sg[T] - g) * aa; b += (sb[T] - b) * aa; }
    const q = (j * w + i) * 4; px[q] = r * 255; px[q + 1] = g * 255; px[q + 2] = b * 255; px[q + 3] = 255;
  }
  if (scale === 1) ctx.putImageData(img, 0, 0);
  else {
    const off = document.createElement("canvas"); off.width = w; off.height = h; off.getContext("2d")!.putImageData(img, 0, 0);
    ctx.imageSmoothingEnabled = true; ctx.drawImage(off, 0, 0, W, H);
  }
}
