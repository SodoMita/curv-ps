// Signed-distance glyph atlas built once with Canvas2D.  Each ASCII glyph
// (32..126) lives in a CELL×CELL cell; the texture stores 0.5 - dist/SPREAD.
export const ATLAS_COLS = 16, ATLAS_ROWS = 6, CELL = 64, FONT_PX = 40, SPREAD = 8;
export const ATLAS_W = ATLAS_COLS * CELL, ATLAS_H = ATLAS_ROWS * CELL;
export const GLYPH_PAD = 10, BASELINE = 44; // glyph origin inside the cell
export const FONT_FAMILY = "Inter, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif";

export interface Atlas {
  data: Uint8Array<ArrayBuffer>; // ATLAS_W*ATLAS_H single channel (r8unorm)
  advance: Float32Array;     // per char code 0..127, in FONT_PX units
  cell(code: number): [number, number]; // cell column,row
}

let cached: Atlas | null = null;

export function buildAtlas(): Atlas {
  if (cached) return cached;
  const cv = document.createElement("canvas"); cv.width = ATLAS_W; cv.height = ATLAS_H;
  const ctx = cv.getContext("2d", { willReadFrequently: true })!;
  ctx.fillStyle = "#000"; ctx.fillRect(0, 0, ATLAS_W, ATLAS_H);
  ctx.fillStyle = "#fff"; ctx.font = `500 ${FONT_PX}px ${FONT_FAMILY}`; ctx.textBaseline = "alphabetic";
  const advance = new Float32Array(128);
  for (let code = 32; code < 127; code++) {
    const i = code - 32, cx = (i % ATLAS_COLS) * CELL, cy = Math.floor(i / ATLAS_COLS) * CELL;
    const ch = String.fromCharCode(code);
    advance[code] = ctx.measureText(ch).width;
    ctx.fillText(ch, cx + GLYPH_PAD, cy + BASELINE);
  }
  const img = ctx.getImageData(0, 0, ATLAS_W, ATLAS_H).data;
  const inside = new Uint8Array(ATLAS_W * ATLAS_H);
  for (let p = 0; p < inside.length; p++) inside[p] = img[p * 4] > 127 ? 1 : 0;
  // brute-force SDF within SPREAD px (cheap enough for 96 glyphs at startup)
  const data = new Uint8Array(new ArrayBuffer(ATLAS_W * ATLAS_H));
  const R = SPREAD;
  const offs: [number, number, number][] = [];
  for (let dy = -R; dy <= R; dy++) for (let dx = -R; dx <= R; dx++) { const d = Math.hypot(dx, dy); if (d <= R) offs.push([dx, dy, d]); }
  offs.sort((a, b) => a[2] - b[2]);
  for (let y = 0; y < ATLAS_H; y++) for (let x = 0; x < ATLAS_W; x++) {
    const p = y * ATLAS_W + x, me = inside[p];
    let best = R;
    for (const [dx, dy, d] of offs) {
      const xx = x + dx, yy = y + dy;
      const other = xx < 0 || yy < 0 || xx >= ATLAS_W || yy >= ATLAS_H ? 0 : inside[yy * ATLAS_W + xx];
      if (other !== me) { best = d; break; }
    }
    const sd = me ? -best : best; // negative inside
    data[p] = Math.max(0, Math.min(255, Math.round((0.5 - sd / (2 * R)) * 255)));
  }
  cached = { data, advance, cell: (code) => { const i = Math.max(0, Math.min(94, code - 32)); return [i % ATLAS_COLS, Math.floor(i / ATLAS_COLS)]; } };
  return cached;
}

export function measureText(atlas: Atlas, text: string, size: number): number {
  let w = 0; for (const ch of text) { const c = ch.charCodeAt(0); w += (advanceOf(atlas, c)) * (size / FONT_PX); }
  return w;
}
export function advanceOf(atlas: Atlas, code: number) { return code >= 32 && code < 127 ? atlas.advance[code] : atlas.advance[32]; }
