import { loadPsolve } from "../src/psolve/psolve";
import { Interp } from "../src/curv/interp";
import { compileProgram } from "../src/curv/shapes";
import { EXAMPLES } from "../src/curv/examples";
import type { Atlas } from "../src/gpu/atlas";
(globalThis as any).performance ??= { now: () => Date.now() };
const adv = new Float32Array(128).fill(22);
const atlas: Atlas = { data: new Uint8Array(new ArrayBuffer(1024*384)), advance: adv, cell: (c) => [(c-32)%16, Math.floor((c-32)/16)] };
await loadPsolve();
for (const ex of EXAMPLES) {
  try {
    const it = new Interp(atlas, { width: 900, height: 520, time: 1.2, mouse: { x: 300, y: 200, down: false } });
    const t0 = Date.now();
    const r = it.run(ex.src);
    const prog = compileProgram(r.shape!, atlas);
    console.log(`OK  ${ex.id.padEnd(10)} instr=${prog.length/12} solves=${r.traces.length} ${r.traces.map(t=>t.engine+':'+t.status+' vars='+t.nVars+' elim='+t.eliminated+' cons='+t.nCons+' '+t.timeMs.toFixed(2)+'ms it='+t.iterations+(t.violations.length?' VIOL '+t.violations.length:'')).join(' | ')} total=${Date.now()-t0}ms`);
    if (ex.id==='split') console.log('   ', r.traces[0].values);
    if (ex.id==='buttons') console.log('   ', r.traces[0].values);
  } catch (e: any) { console.log(`ERR ${ex.id}: ${e.message} (line ${e.line})`); }
}
