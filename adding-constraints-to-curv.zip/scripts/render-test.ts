import { createCanvas } from "@napi-rs/canvas";
import { writeFileSync } from "fs";
import { loadPsolve } from "../src/psolve/psolve";
import { Interp } from "../src/curv/interp";
import { compileProgram } from "../src/curv/shapes";
import { EXAMPLES } from "../src/curv/examples";
import { buildAtlas } from "../src/gpu/atlas";
import { renderCPU } from "../src/gpu/cpu";
(globalThis as any).document = { createElement: (t: string) => { if (t !== "canvas") throw new Error(t); return createCanvas(1, 1) as any; } };
await loadPsolve();
const atlas = buildAtlas();
const W = 640, H = 400;
for (const id of process.argv.slice(2)) {
  const ex = EXAMPLES.find((e) => e.id === id)!;
  const it = new Interp(atlas, { width: W, height: H, time: 1.0, mouse: { x: 420, y: 60, down: false } });
  const r = it.run(ex.src);
  const prog = compileProgram(r.shape!, atlas);
  const cv = createCanvas(W, H); const ctx = cv.getContext("2d") as any;
  const t0 = Date.now();
  renderCPU(ctx, W, H, prog, [0x0e / 255, 0x13 / 255, 0x22 / 255], atlas);
  console.log(id, "rendered in", Date.now() - t0, "ms; instr", prog.length / 12);
  writeFileSync(`/tmp/t/${id}.png`, cv.toBuffer("image/png"));
}
